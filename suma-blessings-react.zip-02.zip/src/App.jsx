import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout/Layout';
import { festivals, occasions } from './data/siteData';
import { generatedRoutes } from './pages/generatedRoutes';
import Home from './pages/Home/Home';
import Contact from './pages/Contact/Contact';
import Campaigns from './pages/Campaigns/Campaigns';
import CauseDetail from './pages/CauseDetail/CauseDetail';
import DonateNow from './pages/DonateNow/DonateNow';
import Login from './pages/Login/Login';
import Register from './pages/Register/Register';
import Events from './pages/Events/Events';
import EventDetail from './pages/EventDetail/EventDetail';
import News from './pages/News/News';
import NewsDetail from './pages/NewsDetail/NewsDetail';
import Projects from './pages/Projects/Projects';
import ProjectDetail from './pages/ProjectDetail/ProjectDetail';
import AllFestivals from './pages/AllFestivals/AllFestivals';
import FestivalDetail from './pages/FestivalDetail/FestivalDetail';
import Gallery from './pages/Gallery/Gallery';
import VideoGallery from './pages/VideoGallery/VideoGallery';
import NotFound from './pages/NotFound/NotFound';
import About from './pages/About/About';
import MissionVision from './pages/MissionVision/MissionVision';
import OurJourney from './pages/OurJourney/OurJourney';
import LegalStatus from './pages/LegalStatus/LegalStatus';
import BoardMembers from './pages/BoardMembers/BoardMembers';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="annual-report" element={<Navigate to="/annual-reports" replace />} />
        <Route path="about" element={<About />} />
        <Route path="mission-vision" element={<MissionVision />} />
        <Route path="our-journey" element={<OurJourney />} />
        <Route path="our-legal-status" element={<LegalStatus />} />
        <Route path="founding-members" element={<BoardMembers />} />
        <Route path="events/details/:slug" element={<EventDetail />} />
        <Route path="contact" element={<Contact />} />
        <Route path="cause" element={<Campaigns />} />
        <Route path="cause/:slug" element={<CauseDetail />} />
        <Route path="donate-now" element={<DonateNow />} />
        <Route path="login" element={<Login />} />
        <Route path="register" element={<Register />} />
        <Route path="events" element={<Events />} />
        <Route path="events/:slug" element={<EventDetail />} />
        <Route path="news" element={<News />} />
        <Route path="news/:slug" element={<NewsDetail />} />
        <Route path="projects" element={<Projects />} />
        <Route path="projects/:slug" element={<ProjectDetail />} />
        <Route path="projects/:category/:slug" element={<ProjectDetail />} />
        <Route path="all-festivals" element={<AllFestivals />} />
        <Route path="gallery" element={<Gallery />} />
        <Route path="video" element={<VideoGallery />} />
        {generatedRoutes.map(({ path, Component }) => (<Route key={path} path={path} element={<Component />} />))}
        {[...festivals, ...occasions].map((f) => (<Route key={f.slug} path={f.slug} element={<FestivalDetail slug={f.slug} />} />))}
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
