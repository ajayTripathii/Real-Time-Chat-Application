import { Link } from 'react-router-dom'
import { Calendar } from 'lucide-react'
import Img from '../components/Img'
import { news } from '../data'
import './News.css'
export default function News(){
  return (<><div className="page-hero"><small>Resource</small><h1>The Suma Blog</h1></div>
  <section className="section"><div className="container grid g3">{news.map(n=><Link key={n.p} to={n.p} className="card reveal"><div className="img"><Img name={n.img}/></div><div className="body"><small className="nd"><Calendar size={13}/> {n.d} • by Team</small><h3>{n.t}</h3></div></Link>)}</div></section></>)
}
