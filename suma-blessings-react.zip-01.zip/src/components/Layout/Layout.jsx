import { Outlet } from 'react-router-dom';
import Header from '../Header/Header';
import Footer from '../Footer/Footer';
import WhatsAppChat from '../WhatsAppChat/WhatsAppChat';
import ScrollToTop from '../ScrollToTop/ScrollToTop';
import DonateModal from '../DonateModal/DonateModal';
import './Layout.css';

export default function Layout() {
  return (
    <div className="layout">
      <Header />
      <main className="layout-main"><Outlet /></main>
      <Footer />
      <WhatsAppChat />
      <ScrollToTop />
      <DonateModal />
    </div>
  );
}
