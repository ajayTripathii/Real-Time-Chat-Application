import { Link } from 'react-router-dom';
import { festivals } from '../../data/siteData';
import './FestivalsSection.css';

export default function FestivalsSection({ all = false }) {
  const list = all ? festivals : festivals;
  return (
    <section className="section alt">
      <div className="container">
        <div className="sec-head">
          <span className="eyebrow">Celebrate & give</span>
          <h2>Donate on Indian Festive Occasion</h2>
          <p>Spread joy this festive season by giving back with a donation to those in need!</p>
        </div>
        <div className="fs-grid">
          {list.map((f) => (
            <Link key={f.slug} to={`/${f.slug}`} className="fs-card">
              <span className="fs-date"><b>{f.day}</b>{f.mon}</span>
              <span><h3>{f.name}</h3><small>{f.day} {f.mon} {f.year}</small></span>
            </Link>
          ))}
        </div>
        {!all && <div className="center mt"><Link to="/all-festivals" className="btn">View all festivals</Link></div>}
      </div>
    </section>
  );
}
