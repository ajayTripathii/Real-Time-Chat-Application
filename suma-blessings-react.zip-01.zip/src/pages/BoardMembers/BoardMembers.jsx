import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './BoardMembers.css';

export default function BoardMembers() {
  return (
    <>
      <PageBanner title="Board Members" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>The people who guide our direction</h2>
            <p>Our board members bring experience from education, healthcare, social work and business to guide the foundation's strategy and governance.</p>
            <p>Add each board member's photo, name and designation here.</p>
            <ul className="ip-list">
              <li>Strategic guidance</li>
              <li>Governance and compliance</li>
              <li>Fundraising support</li>
              <li>Community outreach</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
