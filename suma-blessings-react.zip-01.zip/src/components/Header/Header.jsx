import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { navMenu, LOGO } from '../../data/siteData';
import { useDonation } from '../../context/DonationContext';
import './Header.css';

export default function Header() {
  const [open, setOpen] = useState(false);
  const [sub, setSub] = useState(null);
  const [stuck, setStuck] = useState(false);
  const { items, setOpen: openCart } = useDonation();
  const { pathname } = useLocation();

  useEffect(() => { setOpen(false); setSub(null); }, [pathname]);
  useEffect(() => {
    const on = () => setStuck(window.scrollY > 60);
    window.addEventListener('scroll', on);
    return () => window.removeEventListener('scroll', on);
  }, []);
  useEffect(() => { document.body.style.overflow = open ? 'hidden' : ''; }, [open]);

  return (
    <header className={`hdr ${stuck ? 'stuck' : ''}`}>
      <div className="hdr-top">
        <div className="container hdr-top-in">
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><Link to="/contact">Contact Us</Link></li>
            <li><Link to="/cause">Campaigns</Link></li>
          </ul>
          <ul>
            <li><Link to="/login">Login</Link></li>
            <li><Link to="/register">Registration</Link></li>
          </ul>
        </div>
      </div>
      <div className="container hdr-main">
        <Link to="/" className="hdr-logo"><img src={LOGO} alt="Suma Blessings Foundation" /></Link>
        <nav className={`hdr-nav ${open ? 'open' : ''}`}>
          <ul>
            {navMenu.map((m, i) => (
              <li key={m.label} className={`has-sub ${sub === i ? 'on' : ''}`}>
                <button type="button" onClick={() => setSub(sub === i ? null : i)}>{m.label} <span className="caret">▾</span></button>
                <ul className="sub">
                  {m.items.map(([l, to]) => (<li key={to + l}><NavLink to={to}>{l}</NavLink></li>))}
                </ul>
              </li>
            ))}
          </ul>
          <Link to="/donate-now" className="btn hdr-donate-m">Donate Now</Link>
        </nav>
        <div className="hdr-actions">
          <button className="cart-btn" onClick={() => openCart(true)} aria-label="Selected donations">♥{items.length > 0 && <b>{items.length}</b>}</button>
          <Link to="/donate-now" className="btn hdr-donate">Donate Now</Link>
          <button className={`burger ${open ? 'x' : ''}`} onClick={() => setOpen(!open)} aria-label="Menu"><i /><i /><i /></button>
        </div>
      </div>
    </header>
  );
}
