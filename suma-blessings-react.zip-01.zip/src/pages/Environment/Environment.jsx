import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './Environment.css';

export default function Environment() {
  return (
    <>
      <PageBanner title="Environment" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Caring for the planet we share</h2>
            <p>We run tree plantation drives and environmental awareness activities, often with the children of Suma Vidyalaya.</p>
            <p>Small actions taught early build a greener tomorrow.</p>
            <ul className="ip-list">
              <li>Tree plantation drives</li>
              <li>World Environment Day activities</li>
              <li>Waste and plastic awareness</li>
              <li>Community clean-up</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
