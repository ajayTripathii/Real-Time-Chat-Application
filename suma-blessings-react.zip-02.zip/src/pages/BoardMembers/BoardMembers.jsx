import { useState } from 'react';
import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import { md } from '../../utils/md';
import './BoardMembers.css';

const members = [{
  name: 'Mr. Basant Jena', role: 'Board Chairperson',
  img: 'https://www.sumablessings.org/assets/images/frontend/board/6856aff8d6a791750511608.jpg',
  short: 'Mr. Basant Jena, a software engineer with over a decade of leadership experience in the corporate sector, founded the Suma Blessings Foundation in 2021. In 2020, he tragically lost his mother, Sumitra...',
  full: [
    "Mr. Basant Jena, a software engineer with over a decade of leadership experience in the corporate sector, founded the Suma Blessings Foundation in 2021. In 2020, he tragically lost his mother, Sumitra Jena (Suma), during the second wave of Covid-19. His mother was a dedicated social worker, and his family has a long history of serving underprivileged communities and contributing to social welfare. To honor his mother's legacy, he established a non-profit organization in her loving memory, naming it **\"Suma Blessings.\"**",
    'There is a phrase in Sanskrit, "**Janani Janma Bhoomi cha swargadapi gariyasi**," which emphasizes the importance of a mother and motherland. Inspired by this concept, he choose his mother\'s name for the organization, referred to as **Janani**, and initiated his first community development project in his motherland, "Kamarpal," referred to as **Janmabhumi**.'],
}];

export default function BoardMembers() {
  const [open, setOpen] = useState(null);
  return (
    <>
      <PageBanner title="Board Members" />
      <section className="section">
        <div className="container center">
          <span className="eyebrow">Leadership & governance</span>
          <p className="bm-lead">Our board guides strategy, safeguards mission integrity, and upholds accountability to communities, donors, and the law.</p>
          <ul className="bm-pills"><li>Governance experience</li><li>Ethical stewardship</li><li>Mission-first decisions</li></ul>
          <ul className="bm-points"><li>Diverse skills & sector experience</li><li>Oversight of programmes & finances</li><li>Open engagement with stakeholders</li></ul>
        </div>
      </section>
      <section className="section alt">
        <div className="container">
          <div className="sec-head"><h2>Board members</h2><p>Meet the people who oversee our programmes, finances, and long-term commitment to communities.</p></div>
          {members.map((m, i) => (
            <article key={m.name} className="card bm-card">
              <img src={m.img} alt={`Photo of ${m.name}`} />
              <div>
                <h3>{m.name}</h3>
                <span className="bm-role">{m.role}</span>
                {open === i ? m.full.map((p) => <p key={p}>{md(p)}</p>) : <p>{m.short}</p>}
                <button className="btn sm outline" onClick={() => setOpen(open === i ? null : i)}>{open === i ? 'Hide profile' : 'Full profile'}</button>
              </div>
            </article>
          ))}
        </div>
      </section>
      <section className="section center">
        <div className="container">
          <h2>Want to connect with our leadership?</h2>
          <p className="bm-lead">For governance queries, partnerships, or media, please reach out through our contact page—we will route your message appropriately.</p>
          <Link to="/contact" className="btn">Get in touch</Link>
        </div>
      </section>
    </>
  );
}
