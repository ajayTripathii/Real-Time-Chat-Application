import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App.jsx';
import { DonationProvider } from './context/DonationContext.jsx';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <DonationProvider>
        <App />
      </DonationProvider>
    </BrowserRouter>
  </React.StrictMode>
);
