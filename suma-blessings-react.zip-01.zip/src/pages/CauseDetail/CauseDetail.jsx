import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import { causes, inr, titleCase } from '../../data/siteData';
import { useDonation } from '../../context/DonationContext';
import './CauseDetail.css';

const amounts = [500, 1000, 2500, 5000];

export default function CauseDetail() {
  const { slug } = useParams();
  const c = causes.find((x) => x.slug === slug);
  const { add } = useDonation();
  const [amt, setAmt] = useState(1000);
  const title = c ? c.title : titleCase(slug);
  return (
    <>
      <PageBanner title={title} crumbs={[['Campaigns', '/cause']]} />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            {c && <img className="cd-img" src={c.img} alt={c.title} />}
            <h2>{title}</h2>
            <p>Your support helps Suma Blessings Foundation reach children, women and families who need it most. Every contribution is used transparently for this campaign and is eligible for tax benefit under Section 80G.</p>
            {c?.details && <ul className="ip-list">{c.details.map(([k, v]) => <li key={k}><b>{k}:</b> {v}</li>)}</ul>}
            {c && (<><div className="ap-bar"><i style={{ width: `${Math.max(c.pct, 1)}%` }}><span>{c.pct}%</span></i></div>
              <p className="cd-nums">Raised <b>{c.meals ? `${c.raised} Meal(s)` : inr(c.raised)}</b> of <b>{c.meals ? `${c.goal.toLocaleString('en-IN')} Meal(s)` : inr(c.goal)}</b></p></>)}
          </div>
          <aside className="ip-side">
            <h3>Support this cause</h3>
            <p>Select an amount to donate</p>
            <div className="cd-amts">{amounts.map((a) => <button key={a} className={amt === a ? 'on' : ''} onClick={() => setAmt(a)}>{inr(a)}</button>)}</div>
            <div className="field"><label>Other amount (₹)</label><input type="number" min="1" value={amt} onChange={(e) => setAmt(e.target.value)} /></div>
            <button className="btn mt" onClick={() => amt > 0 && add({ id: slug, title, amount: amt })}>Donate Now</button>
            <p className="mt"><Link to="/cause">← Back to all campaigns</Link></p>
          </aside>
        </div>
      </section>
    </>
  );
}
