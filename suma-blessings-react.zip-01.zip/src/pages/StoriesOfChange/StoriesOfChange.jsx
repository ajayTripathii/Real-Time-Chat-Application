import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './StoriesOfChange.css';

export default function StoriesOfChange() {
  return (
    <>
      <PageBanner title="Stories of Change" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Real lives, real impact</h2>
            <p>Behind every number is a person. These stories show how education, food, healthcare and skills have changed lives.</p>
            <p>Add beneficiary stories with photos here.</p>
            <ul className="ip-list">
              <li>Students who found their voice</li>
              <li>Women who became earners</li>
              <li>Families who got healthcare</li>
              <li>Communities that came together</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
