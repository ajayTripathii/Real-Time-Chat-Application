import { useState, useEffect } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { Menu, X, ChevronDown, Phone, Mail, Heart } from 'lucide-react'
import { nav, contact } from '../data'
import './Header.css'
export default function Header(){
  const [open,setOpen]=useState(false),[sub,setSub]=useState(null),[stuck,setStuck]=useState(false)
  const loc=useLocation()
  useEffect(()=>{setOpen(false);setSub(null)},[loc.pathname])
  useEffect(()=>{const f=()=>setStuck(scrollY>60);addEventListener('scroll',f);return()=>removeEventListener('scroll',f)},[])
  return (<header className={'hdr'+(stuck?' stuck':'')}>
    <div className="top"><div className="container row">
      <div className="contact"><a href={`tel:${contact.phone}`}><Phone size={14}/> {contact.phone}</a><a href={`mailto:${contact.email}`}><Mail size={14}/> {contact.email}</a></div>
      <div className="tl"><Link to="/">Home</Link><Link to="/contact">Contact Us</Link><Link to="/cause">Campaigns</Link><Link to="/login">Login</Link><Link to="/register">Registration</Link></div>
    </div></div>
    <div className="container row main">
      <Link to="/" className="logo"><span><Heart size={20} fill="#fff"/></span>Suma <b>Blessings</b></Link>
      <nav className={open?'open':''}>
        {nav.map((g,n)=>(<div key={g.label} className={'dd'+(sub===n?' show':'')}>
          <button onClick={()=>setSub(sub===n?null:n)}>{g.label}<ChevronDown size={15}/></button>
          <ul>{g.items.map(([l,p])=><li key={p}><NavLink to={p}>{l}</NavLink></li>)}</ul></div>))}
        <Link to="/donate-now" className="btn mob">Donate Now</Link>
      </nav>
      <Link to="/donate-now" className="btn desk"><Heart size={16}/> Donate Now</Link>
      <button className="burger" onClick={()=>setOpen(!open)} aria-label="Menu">{open?<X/>:<Menu/>}</button>
    </div></header>)
}
