import PageBanner from '../../components/PageBanner/PageBanner';
import Reveal from '../../components/Reveal/Reveal';
import { md } from '../../utils/md';
import './About.css';

const objectives = [
  'To help alleviate poverty by enabling access to the basic necessities of life including safe and nutritious food; clean and safe drinking water, shelter, education, medicine, and livelihoods for people deprived from such access.',
  'To promote social welfare activities intended for the general welfare of the public such as welfare of the destitute, family, women, children, orphans, senior citizens and the handicapped, and assistance in cases of calamity, un-employment, under employment, old age, sickness, disablement and other cases of deserving needs.',
  'To give, provide and/or render legal, medical, socio-economic/financial and all available means of help and assistance including implementation of any scheme for providing livelihood and upliftment of the poor, deserving and other needy persons.',
  'To encourage sports by providing coaching, training, equipment, guidance, financial assistance and other means of help to the less privileged persons.',
  'To promote and conduct activities for the welfare of animals including stray and sick animals.',
];

export default function About() {
  return (
    <>
      <PageBanner title="About Us" />
      <section className="section ab-intro">
        <div className="container center">
          <span className="eyebrow">Who we are</span>
          <p className="ab-lead">We are people-first, grounded in dignity and solidarity—partnering with communities to build lasting wellbeing through care, transparency, and action.</p>
          <ul className="ab-pills"><li>Community-centered</li><li>Compassion in action</li><li>Accountable impact</li></ul>
        </div>
      </section>
      <section className="section alt">
        <Reveal><div className="container ab-split">
          <img src="https://www.sumablessings.org/assets/images/frontend/about/63abd8f9c91331672206585.jpg" alt="About Suma Blessings Foundation" />
          <div>
            <h2>About Suma Blessings Foundation</h2>
            <p>{md('Suma Blessings Foundation, established in 2021, is a not for profit organization committed to the holistic development of marginalized communities. Our mission is to uplift individuals and families who face **social and economic disadvantages**, by addressing not just their immediate needs but their long-term sustainable growth and well-being. We believe in a comprehensive approach that empowers people through **education, healthcare, livelihood support, and community engagement**. By focusing on the whole person and their environment, we strive to create lasting change that breaks cycles of poverty and inequality. Since our inception, we have collaborated with **local leaders, volunteers, and like-minded partners** to create inclusive spaces where hope can flourish and lives can be transformed. Each project we take on is a step toward a world where every individual—regardless of their background—has the opportunity to thrive.')}</p>
            <p>At Suma Blessings Foundation, we don’t just offer support—we nurture potential, inspire resilience, and work hand-in-hand with communities to build a more just, compassionate, and empowered society.</p>
          </div>
        </div></Reveal>
      </section>
      <section className="section">
        <Reveal><div className="container ab-split rev">
          <div>
            <span className="eyebrow">What shapes our work</span>
            <h2>Our Objectives</h2>
            <ul className="ip-list">{objectives.map((o) => <li key={o}>{o}</li>)}</ul>
          </div>
          <img src="https://www.sumablessings.org/assets/images/frontend/about/676eeb311a9661735322417.JPG" alt="Our Objectives" />
        </div></Reveal>
      </section>
    </>
  );
}
