# Suma Blessings – React site
npm install && npm run dev
- Content: src/data.js (all text, links, stats)
- Images: put files in public/images/ with the names used in data.js (slide1.jpg, p1.jpg, a1.jpg, ...). Missing ones show gradient placeholders.
- Pages: src/pages/<Name>.jsx + <Name>.css; unmatched routes use InfoPage driven by data.js
