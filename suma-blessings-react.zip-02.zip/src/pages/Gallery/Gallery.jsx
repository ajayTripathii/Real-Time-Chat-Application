import { useState } from 'react';
import PageBanner from '../../components/PageBanner/PageBanner';
import Lightbox from '../../components/Lightbox/Lightbox';
import { categories, blogs, projects, causes, occasions } from '../../data/siteData';
import './Gallery.css';

const imgs = [...categories.map((c) => [c.img, c.name]), ...projects.map((p) => [p.img, p.title]), ...causes.map((c) => [c.img, c.category]), ...occasions.map((o) => [o.img, o.name]), ...blogs.map((b) => [b.img, b.title])];

export default function Gallery() {
  const [i, setI] = useState(null);
  return (
    <>
      <PageBanner title="Image Gallery" />
      <section className="section"><div className="container gl-grid">
        {imgs.map(([src, alt], k) => (<figure key={k} onClick={() => setI(k)} tabIndex={0} onKeyDown={(e) => e.key === 'Enter' && setI(k)}><img src={src} alt={alt} loading="lazy" /><figcaption>{alt}</figcaption></figure>))}
      </div></section>
      {i !== null && <Lightbox items={imgs} index={i} onClose={() => setI(null)} onChange={setI} />}
    </>
  );
}
