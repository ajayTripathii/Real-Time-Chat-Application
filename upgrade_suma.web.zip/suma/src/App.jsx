import { Routes, Route, useLocation } from 'react-router-dom'
import { useEffect, useState } from 'react'
import Header from './components/Header'
import Footer from './components/Footer'
import useReveal from './useReveal'
import Home from './pages/Home'
import About from './pages/About'
import Causes from './pages/Causes'
import Events from './pages/Events'
import News from './pages/News'
import Contact from './pages/Contact'
import Donate from './pages/Donate'
import InfoPage from './pages/InfoPage'
export default function App(){
  const loc=useLocation(),[ld,setLd]=useState(false)
  useEffect(()=>{window.scrollTo(0,0);setLd(true);const t=setTimeout(()=>setLd(false),550);return()=>clearTimeout(t)},[loc.pathname])
  useReveal(loc.pathname)
  return (<>
    <div className={'route-bar'+(ld?' go':'')}/>
    <Header/>
    <main key={loc.pathname} className="page-anim">
      <Routes location={loc}>
        <Route path="/" element={<Home/>}/><Route path="/about" element={<About/>}/>
        <Route path="/cause" element={<Causes/>}/><Route path="/events" element={<Events/>}/>
        <Route path="/news" element={<News/>}/><Route path="/contact" element={<Contact/>}/>
        <Route path="/donate-now" element={<Donate/>}/><Route path="*" element={<InfoPage/>}/>
      </Routes>
    </main>
    <Footer/>
  </>)
}
