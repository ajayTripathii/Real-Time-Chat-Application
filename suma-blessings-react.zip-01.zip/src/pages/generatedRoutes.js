import About from './About/About';
import MissionVision from './MissionVision/MissionVision';
import OurJourney from './OurJourney/OurJourney';
import LegalStatus from './LegalStatus/LegalStatus';
import BoardMembers from './BoardMembers/BoardMembers';
import Team from './Team/Team';
import Education from './Education/Education';
import FoodNutrition from './FoodNutrition/FoodNutrition';
import Healthcare from './Healthcare/Healthcare';
import WomenEmpowerment from './WomenEmpowerment/WomenEmpowerment';
import Environment from './Environment/Environment';
import AwarenessProgram from './AwarenessProgram/AwarenessProgram';
import ResearchDevelopment from './ResearchDevelopment/ResearchDevelopment';
import SkillDevelopmentProgram from './SkillDevelopmentProgram/SkillDevelopmentProgram';
import CorporatePartnership from './CorporatePartnership/CorporatePartnership';
import Csr from './Csr/Csr';
import SchoolPartnerships from './SchoolPartnerships/SchoolPartnerships';
import PrintOnlineMedia from './PrintOnlineMedia/PrintOnlineMedia';
import ElectronicMedia from './ElectronicMedia/ElectronicMedia';
import AnnualReports from './AnnualReports/AnnualReports';
import StoriesOfChange from './StoriesOfChange/StoriesOfChange';
import PrivacyPolicy from './PrivacyPolicy/PrivacyPolicy';
import TermsAndCondition from './TermsAndCondition/TermsAndCondition';
import RefundPolicy from './RefundPolicy/RefundPolicy';
import BecomeMember from './BecomeMember/BecomeMember';
import BecomeIntern from './BecomeIntern/BecomeIntern';
import Volunteering from './Volunteering/Volunteering';
import Career from './Career/Career';
import Newsletter from './Newsletter/Newsletter';

export const generatedRoutes = [
  { path: 'about', Component: About },
  { path: 'mission-vision', Component: MissionVision },
  { path: 'our-journey', Component: OurJourney },
  { path: 'our-legal-status', Component: LegalStatus },
  { path: 'founding-members', Component: BoardMembers },
  { path: 'team', Component: Team },
  { path: 'education', Component: Education },
  { path: 'food-nutrition', Component: FoodNutrition },
  { path: 'healthcare', Component: Healthcare },
  { path: 'women-empowerment', Component: WomenEmpowerment },
  { path: 'environment', Component: Environment },
  { path: 'awareness-program', Component: AwarenessProgram },
  { path: 'research-development', Component: ResearchDevelopment },
  { path: 'skill-development-program', Component: SkillDevelopmentProgram },
  { path: 'corporate-partnership', Component: CorporatePartnership },
  { path: 'csr', Component: Csr },
  { path: 'school-partnerships', Component: SchoolPartnerships },
  { path: 'print-online-media', Component: PrintOnlineMedia },
  { path: 'electronic-media', Component: ElectronicMedia },
  { path: 'annual-reports', Component: AnnualReports },
  { path: 'stories-of-change', Component: StoriesOfChange },
  { path: 'privacy-policy', Component: PrivacyPolicy },
  { path: 'terms-and-condition', Component: TermsAndCondition },
  { path: 'refund-policy', Component: RefundPolicy },
  { path: 'become-a-member', Component: BecomeMember },
  { path: 'become-an-intern', Component: BecomeIntern },
  { path: 'volunteering-opportunities', Component: Volunteering },
  { path: 'career', Component: Career },
  { path: 'newsletter', Component: Newsletter },
];
