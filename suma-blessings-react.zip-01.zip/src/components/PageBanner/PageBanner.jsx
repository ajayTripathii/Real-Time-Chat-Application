import { Link } from 'react-router-dom';
import './PageBanner.css';

export default function PageBanner({ title, crumbs = [] }) {
  return (
    <section className="pb">
      <div className="container">
        <h1>{title}</h1>
        <ul className="pb-crumbs">
          <li><Link to="/">Home</Link></li>
          {crumbs.map(([l, to]) => (<li key={l}>{to ? <Link to={to}>{l}</Link> : l}</li>))}
          <li>{title.length > 40 ? title.slice(0, 40) + '…' : title}</li>
        </ul>
      </div>
    </section>
  );
}
