import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './About.css';

export default function About() {
  return (
    <>
      <PageBanner title="About Suma Blessings Foundation" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Holistic development of marginalized communities</h2>
            <p>Suma Blessings Foundation, established in 2021, is a not for profit organization committed to the holistic development of marginalized communities.</p>
            <p>Working across 3 states, we run education centers, nutrition drives, healthcare camps and skill programmes that have benefited over 1 million people.</p>
            <ul className="ip-list">
              <li>Education</li>
              <li>Healthcare</li>
              <li>Community development</li>
              <li>Transparent, 80G-eligible giving</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
