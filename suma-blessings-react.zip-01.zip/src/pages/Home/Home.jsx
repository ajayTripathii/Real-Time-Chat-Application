import HeroSlider from '../../components/HeroSlider/HeroSlider';
import CategoryStrip from '../../components/CategoryStrip/CategoryStrip';
import RegisteredNgo from '../../components/RegisteredNgo/RegisteredNgo';
import AboutSection from '../../components/AboutSection/AboutSection';
import CsrSection from '../../components/CsrSection/CsrSection';
import ProjectsSection from '../../components/ProjectsSection/ProjectsSection';
import AppealsSection from '../../components/AppealsSection/AppealsSection';
import InvolvedSection from '../../components/InvolvedSection/InvolvedSection';
import FestivalsSection from '../../components/FestivalsSection/FestivalsSection';
import OccasionsSection from '../../components/OccasionsSection/OccasionsSection';
import EventsSection from '../../components/EventsSection/EventsSection';
import BlogSection from '../../components/BlogSection/BlogSection';
import './Home.css';

export default function Home() {
  return (
    <div className="home">
      <HeroSlider />
      <CategoryStrip />
      <RegisteredNgo />
      <AboutSection />
      <CsrSection />
      <ProjectsSection />
      <AppealsSection />
      <InvolvedSection />
      <FestivalsSection />
      <OccasionsSection />
      <EventsSection />
      <BlogSection />
    </div>
  );
}
