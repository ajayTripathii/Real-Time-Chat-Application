const A = 'https://www.sumablessings.org/assets/images/';
export const LOGO = A + 'logoIcon/logo.png';
export const FAVICON = 'https://www.sumablessings.org/logo/favicon.png';
export const PHONE = '+91 9971759656';
export const EMAIL = 'info@sumablessings.org';
export const ADDRESS = 'House No. 462, Baprola Road, Najafgarh, New Delhi – 110043';

export const navMenu = [
  { label: 'About Us', items: [
    ['About Suma Blessings', '/about'], ['Mission & Vision', '/mission-vision'], ['Our Journey', '/our-journey'],
    ['Legal Status', '/our-legal-status'], ['Board Members', '/founding-members'], ['Management Team', '/team'] ] },
  { label: 'What We do', items: [
    ['Education', '/education'], ['Food & Nutrition', '/food-nutrition'], ['Healthcare', '/healthcare'],
    ['Women Empowerment', '/women-empowerment'], ['Environment', '/environment'],
    ['Awareness Program', '/awareness-program'], ['Research & Development', '/research-development'] ] },
  { label: 'Projects', items: [
    ['Child Education', '/projects/child-education'], ['Skill Development', '/projects/skill-development'],
    ['Food & Nutrition', '/projects/health-and-nutrition'], ['Healthcare', '/projects/healthcare'],
    ['Environmental Sustainability', '/projects/environment'], ['Women Empowerment', '/projects/women-empowerment'] ] },
  { label: 'Get Involved', items: [
    ['Corporate Partnership', '/corporate-partnership'], ['School Partnerships', '/school-partnerships'],
    ['Volunteers', '/volunteering-opportunities'], ['Internships', '/become-an-intern'],
    ['Membership', '/become-a-member'], ['Work with Us', '/career'] ] },
  { label: 'Media', items: [
    ['Image Gallery', '/gallery'], ['Video Gallery', '/video'], ['Workshops & Events', '/events'],
    ['Print / Online Media', '/print-online-media'], ['Electronic Media', '/electronic-media'] ] },
  { label: 'Resource', items: [
    ['The Suma Blog', '/news'], ['Newsletter', '/newsletter'], ['Annual Reports', '/annual-reports'],
    ['Stories of Change', '/stories-of-change'] ] },
];

export const heroSlides = [
  { tag: 'Disability Inclusion', title: 'Empowering Persons with Disabilities Through Inclusion', to: '/projects/suma-saksham-disability-inclusion', bg: 'linear-gradient(120deg,#0f3552,#1d6a8f)' },
  { tag: 'Empowering Skills, Creating Opportunities', title: 'Equipping underserved communities with practical skills, vocational training, and livelihood opportunities for a brighter future.', to: '/skill-development-program', bg: 'linear-gradient(120deg,#7a2e0e,#f26a21)' },
  { tag: 'Bringing Healthcare Closer to Those in Need', title: 'Empowering underserved communities through healthcare support, awareness, and access to essential medical services.', to: '/healthcare', bg: 'linear-gradient(120deg,#0b5c4d,#1aa38b)' },
  { tag: '500 Families • 1 Mission • Countless Smiles', title: 'Join our Diwali Joy Kit Drive and help 500 families celebrate the festival with joy and dignity.', to: '/events/diwali-joy-kit-distribution-2025', bg: 'linear-gradient(120deg,#6b1d4f,#e0529c)' },
  { tag: 'Child Education', title: 'A community-based educational center designed to support children from underprivileged backgrounds.', to: '/education', bg: 'linear-gradient(120deg,#1f3a93,#4f7cff)' },
  { tag: 'Women Empowerment', title: 'Supporting women in realizing their dreams', to: '/womens-day', bg: 'linear-gradient(120deg,#5b2a86,#b06ad8)' },
  { tag: 'Suma Vidyalaya', title: 'Every child deserves a bright future, and our community-based educational center is here to make that happen', to: '/projects/child-education/suma-vidyalaya', bg: 'linear-gradient(120deg,#8a4b00,#f2a21f)' },
];

export const categories = [
  ['Skill Development', 'category/688b76f37e5581753970419.jpg'], ['Environment', 'category/67558006d74301733656582.jpg'],
  ['Food & Nutrition', 'category/66d0aee7564831724952295.jpg'], ['Healthcare', 'category/664f3bf005a781716468720.jpg'],
  ['Women Empowerment', 'category/63d22645a8eff1674716741.jpg'], ['Education', 'category/63d252b182eac1674728113.jpg'],
  ['Children', 'category/63cee45b700d01674503259.jpg'],
].map(([name, img]) => ({ name, img: A + img }));

export const ngoPrograms = [
  ['Child Education', '/education'], ['Healthcare', '/healthcare'], ['Food and Nutrition', '/food-nutrition'],
  ['Women Empowerment', '/women-empowerment'], ['Skill Development', '/skill-development-program'],
  ['Save the Environment', '/environment'], ['Awareness Program', '/awareness-program'], ['Research and Development', '/research-development'],
];

export const aboutStats = [['3', 'States'], ['1 Million+', 'Meals served'], ['15+', 'Education Centers and Schools'], ['5000+', 'Students']];

export const projects = [
  { slug: 'suma-saksham-disability-inclusion', title: 'Suma Saksham', text: 'Empowering Abilities, Creating Equal Opportunities', img: 'blog/6b02d9273b52b1795348775.jpg', stats: [] },
  { slug: 'general-duty-assistant-training', title: 'Suma Care', text: 'General Duty Assistant (GDA) Training Initiative', img: 'blog/6af9eab2e3a051794763442.jpg', stats: [] },
  { slug: 'silai-se-samriddhi', title: 'Silai Se Samriddhi', text: 'Hunar Se Samman, Silai Se Samriddhi', img: 'blog/68f679ca730661760983498.jpg', stats: ['200+ women enrolled', '10+ Self-help groups', '30+ Women trained per batch'] },
  { slug: 'suma-aarogya-raah', title: 'Suma Aarogya Raah', text: 'Providing access to healthcare for all.', img: 'blog/6919dc418b3751763302465.jpg', stats: ['20+ Health camps conducted', '3000+ Beneficiaries', '500+ Sanitary kits distributed'] },
  { slug: 'suma-spoon-of-love', title: 'Suma Spoon of Love', text: "More Than Food. It's Love Served on a Plate.", img: 'blog/676ff530610a91735390512.jpeg', stats: ['1M+ Food Distributed', '30+ Communities Reached', '1800+ Ration kits delivered'] },
].map((p) => ({ ...p, img: A + p.img }));

export const causes = [
  { slug: 'sanitary-dignity-kits', title: 'Sanitary Dignity Kits – Empowering Adolescent Girls with Confidence and Care', img: 'campaign/6859da08c895f1750718984.jpg', pct: 53.5, raised: 58853, goal: 110000, category: 'Women Empowerment' },
  { slug: 'request-for-medical-financial-assistance-for-souray-raikwar', title: 'Request For Medical Financial Assistance For Souray Raikwar', img: 'campaign/66719e50030031718722128.jpeg', pct: 66.6, raised: 380815, goal: 571765, category: 'Healthcare',
    details: [['Name', 'Souray Raikwar'], ['Father', 'Mr. Jeetu Raikwar'], ['Problem', 'Multiple Congenital Heart Defects'], ['Treatment at', 'AIIMS, New Delhi']] },
  { slug: 'basic-computer-training-for-poor-children', title: 'Donate Desktop for Suma Vidyalaya’s Children- Help Bridge the Digital Divide for Underserved Learners', img: 'campaign/63d2563f462801674729023.jpg', pct: 11, raised: 38500, goal: 350000, category: 'Education' },
  { slug: 'sponsor-meals-for-a-poor-tribal-child', title: 'Sponsor a Meal – Nourish a Tribal Community- A Campaign to Feed the Underserved Tribal.', img: 'campaign/63cfddd20f2051674567122.jpg', pct: 0.01, raised: 5, goal: 36000, category: 'Food & Nutrition', meals: true },
].map((c) => ({ ...c, img: A + c.img }));

export const involved = [
  { title: 'Membership', to: '/become-a-member', img: 'frontend/feature2/677d554590bef1736267077.jpg', text: 'Membership is open to everyone who may not have the time or ability to work online or offline. In either case, individuals can contribute a monthly donation and become members of the organization. Members can also sponsor education, food, and healthcare for underprivileged children.' },
  { title: 'Internship', to: '/become-an-intern', img: 'frontend/feature2/677d553625cec1736267062.jpg', text: 'Internships are open to anyone who can commit to a minimum duration of work, whether on-site or online. All interns receive a certificate upon completing their agreed-upon work period. You can select from a variety of available internship positions.' },
  { title: 'Volunteership', to: '/volunteering-opportunities', img: 'frontend/feature2/677d4f8f9bed31736265615.jpg', text: 'Volunteering is open to everyone, whether you prefer to work in person or online, and you can contribute according to your availability. There are no commitments required for volunteering, and participants do not receive certificates.' },
].map((i) => ({ ...i, img: A + i.img }));

const f = (day, mon, year, name, slug) => ({ day, mon, year, name, slug });
export const festivals = [
  f('25', 'Dec', '2026', 'Merry Christmas', 'merry-christmas'), f('01', 'Jan', '2027', 'Happy New Year', 'newyear'),
  f('13', 'Jan', '2026', 'Lohri', 'lohri'), f('14', 'Jan', '2026', 'Makar Sankranti', 'makar-sankranti'),
  f('15', 'Jan', '2026', 'Pongal', 'pongal'), f('23', 'Jan', '2026', 'Basant Panchami', 'basant-panchami'),
  f('15', 'Feb', '2026', 'Mahashivratri', 'mahashivratri'), f('04', 'Mar', '2026', 'Happy Holi', 'holi'),
  f('08', 'Mar', '2026', "Women's Day", 'womens-day'), f('19', 'Mar', '2026', 'Chaitra Navratri', 'chaitra-navratri-charity'),
  f('19', 'Mar', '2026', 'Gudi Padwa', 'gudi-padwa'), f('15', 'Aug', '2026', 'Independence Day', 'independence-day'),
  f('28', 'Aug', '2026', 'Raksha Bandhan', 'raksha-bandhan'), f('04', 'Sep', '2026', 'Janmashtami', 'janmashtami'),
  f('14', 'Sep', '2026', 'Ganesh Chaturthi', 'donate-on-this-ganesh-chaturthi'), f('26', 'Sep', '2026', 'Pitru Paksha Donation', 'pitrupaksha-donation'),
  f('02', 'Oct', '2026', 'Daan Utsav', 'daan-utsav'), f('11', 'Oct', '2026', 'Navratri Donation', 'navratri-donation'),
  f('25', 'Oct', '2026', 'Sharad Purnima', 'sharad-purnima'), f('06', 'Nov', '2026', 'Diwali Celebration', 'diwali-donation'),
  f('06', 'Nov', '2026', 'Dhanteras', 'dhanteras'), f('13', 'Nov', '2026', 'Chhath Puja', 'chhath-puja'),
  f('14', 'Nov', '2026', "Children's Day", 'children-day'),
];

export const occasions = [
  ['Birthday Donation', 'birthday', 'blog/66b660131f5561723228179.jpg'], ['Anniversary', 'anniversary-donation', 'blog/66b65ff874bb41723228152.jpg'],
  ["Mother's Day", 'mothers-day', 'blog/674460d34e40c1732534483.jpg'], ['Death Anniversary', 'death-anniversary', 'blog/67930c463ff831737690182.jpg'],
  ["Valentine's day", 'valentine-day', 'blog/67968c4645b2d1737919558.jpg'], ['Donate in Honor', 'donate-in-honor', 'blog/6a3e863031bcd1782482480.png'],
].map(([name, slug, img]) => ({ name, slug, img: A + img }));

export const events = [
  { slug: 'menstrual-health-hygiene-camp-in-delhi-cantt', day: '19', mon: 'Nov', title: 'Menstrual Health & Hygiene Workshop & Sanitary Pads Distribution Camp', text: 'Suma Blessings Foundation, in association with Pinkishe Foundation, organised a Menstrual Health & Hygiene Workshop and Sanitary Pads Distribution Camp.', venue: 'Delhi Cant, New Delhi' },
  { slug: 'ai-learning-session-2026', day: '14', mon: 'Nov', title: 'AI Learning Session 2026 – Empowering Young Minds Through Artificial Intelligence', text: 'Suma Blessings Foundation successfully organised an AI Learning Session on 14th November 2026 at its Baprola Vihar Centre, New Delhi.', venue: 'Baprola Viihar, Najafgarh, New Delhi' },
  { slug: 'diwali-celebration-at-suma-vidyalaya-spreading-happiness-sharing-love', day: '07', mon: 'Nov', title: 'Diwali Celebration at Suma Vidyalaya – Spreading Happiness, Sharing Love!', text: 'Suma Blessings Foundation celebrated Diwali 2026 with 50+ children at Suma Vidyalaya, Baprola Vihar. The celebration spread happiness, love and festive joy.' },
  { slug: 'breast-cancer-awareness-research-session', day: '30', mon: 'Sep', title: 'Breast Cancer Awareness & Research Session', text: 'Suma Blessings Foundation organised a Breast Cancer Awareness & Women’s Health Session with Dr. Shalu, focusing on awareness and early detection.', venue: 'House No. 462, Baprola Road, Najafgarh, New Delhi – 110043', time: '11:00AM to 1:00PM' },
  { slug: '80th-independence-day-celebrated-with-children-at-suma-vidyalaya', day: '15', mon: 'Aug', title: '80th Independence Day Celebrated with Children at Suma Vidyalaya', text: 'Suma Blessings Foundation celebrated India’s 80th Independence Day with the children of Suma Vidyalaya through flag hoisting and patriotic activities.', venue: 'Uttam Nagar, New Delhi', time: '9:00 AM to 11:00 AM' },
];

const b = (slug, title, date, img) => ({ slug, title, date, img: A + 'blog/' + img });
export const blogs = [
  b('celebrate-your-birthday-with-underprivileged-children', 'Celebrate Your Birthday with Underprivileged Children: A Meaningful Way to Give Back', 'Oct 14, 2026', '6ad012af73e821792021167.png'),
  b('raksha-bandhan-2026', 'Raksha Bandhan 2026: Celebrating the Bond of Love Through Care, Education and Empowerment', 'Aug 17, 2026', '6a833710c8d081786984208.jpg'),
  b('friendship-day-2026', 'Friendship Day 2026: Celebrating Friendship Through Kindness and Compassion', 'Jul 30, 2026', '6a6b362043f751785411104.png'),
  b('world-lung-cancer-day-2026', 'World Lung Cancer Day 2026: Every Breath Matters', 'Jul 30, 2026', '6a6b320192eee1785410049.png'),
  b('navratri-types-a-complete-guide-to-the-4-navratris-in-india', 'Navratri Types: A Complete Guide to the 4 Navratris in India', 'Mar 19, 2026', '69bc190db3da61773934861.png'),
  b('importance-of-daan-on-basant-panchami-donate-for-saraswati-puja', 'Importance of Daan on Basant Panchami | Donate for Saraswati Puja', 'Jan 13, 2026', '6965f6885b9061768289928.png'),
  b('how-daan-utsav-2025', 'How Daan Utsav 2025 Inspires Collective Giving and Social Change with Suma Blessings Foundation', 'Sep 23, 2025', '68d2f0e895edd1758654696.jpg'),
  b('empowering-sustainability-through-participation', 'Empowering Sustainability through Participation - Suma Blessings Foundation at India CSR & Sustainability Conclave 2025', 'Aug 6, 2025', '68933ed6a5c671754480342.jpg'),
  b('world', "World Environment Day with Suma Vidyalaya's Underprivileged Children: A Day of Tree Planting", 'Jun 8, 2025', '6845a38408ebb1749394308.jpg'),
  b('maha-kumbh-mela-2025', 'The Ultimate Guide to Maha Kumbh Mela 2025: Everything You Need to Know', 'Jan 5, 2025', '677a8005779811736081413.jpg'),
  b('new-year-new-you-why-helping-others-should-top-your-resolution-list', 'New Year, New You: Why Helping Others Should Top Your Resolution List', 'Nov 28, 2024', '6748061a095fb1732773402.jpg'),
  b('celebrate-diwali-with-underprivileged-children-at-suma-vidyalaya', 'Celebrate Diwali with Underprivileged Children at Suma Vidyalaya', 'Oct 25, 2024', '671b7aa9719e31729854121.jpeg'),
  b('fundraising-event-for-underprivileged-children', "Celebrating Durga Puja with a Purpose: Suma Blessings Foundation's Fundraising Event for Underprivileged Children", 'Oct 10, 2024', '670801e8428dd1728578024.jpeg'),
  b('independence-day-2024', 'A Guide to Enjoying Independence Day 2024 Responsibly', 'Aug 9, 2024', '66b62411f1d9e1723212817.jpg'),
];

export const socials = [
  ['YouTube', 'https://www.youtube.com/@sumablessings', 'M10 15l5.2-3L10 9v6zm11-3c0-2.2-.2-3.6-.5-4.4-.3-.7-.9-1.3-1.6-1.5C17.7 5.8 12 5.8 12 5.8s-5.700 0-6.900.3c-.7.2-1.300.8-1.600 1.500C3.200 8.400 3 9.800 3 12s.2 3.600.5 4.400c.3.700.9 1.300 1.600 1.500 1.200.3 6.900.3 6.900.3s5.700 0 6.900-.3c.7-.2 1.300-.8 1.600-1.500.3-.8.5-2.200.5-4.400z'],
  ['LinkedIn', 'https://www.linkedin.com/company/sumablessings/', 'M6 9h3v10H6zM7.500 4.500a1.800 1.800 0 110 3.600 1.800 1.800 0 010-3.600zM11 9h2.900v1.400c.5-.9 1.600-1.600 3.100-1.600 3 0 3.500 2 3.500 4.500V19h-3v-5c0-1.200 0-2.600-1.600-2.600S14 12.700 14 14v5h-3z'],
  ['Twitter', 'https://www.twitter.com/sumablessings', 'M20 7.500c-.5.2-1 .4-1.600.5.600-.3 1-.9 1.200-1.500-.5.300-1.100.5-1.800.7a2.800 2.800 0 00-4.800 2.600A8 8 0 016 6.800a2.800 2.800 0 00.900 3.700c-.5 0-.9-.1-1.300-.4 0 1.300.9 2.400 2.200 2.700-.4.100-.8.100-1.200 0 .3 1.100 1.400 1.900 2.600 1.900A5.600 5.600 0 014 16a8 8 0 0012.300-7v-.4c.7-.5 1.200-1 1.700-1.700z'],
  ['Instagram', 'https://www.instagram.com/sumablessings', 'M8 4h8a4 4 0 014 4v8a4 4 0 01-4 4H8a4 4 0 01-4-4V8a4 4 0 014-4zm4 4.500a3.500 3.500 0 100 7 3.500 3.500 0 000-7zm4.800-1.800a.9.9 0 100 1.800.9.9 0 000-1.800z'],
  ['Facebook', 'https://www.facebook.com/sumablessings', 'M14 8h2.500V5H14c-2 0-3.500 1.500-3.500 3.500V10H8v3h2.500v6h3v-6h2.300l.4-3h-2.700V8.700c0-.4.200-.7.500-.7z'],
];

export const whatsappTeam = [['Gaurav Dwivedi', 'Fund-Raising Manager'], ['Arshita', 'Project Co-ordinator']];
export const WHATSAPP = 'https://api.whatsapp.com/send?phone=917065081060&text=Hello%2C%20I%20want%20to%20donate.%20https%3A%2F%2Fwww.sumablessings.org';
export const inr = (n) => '₹' + Number(n).toLocaleString('en-IN');
export const titleCase = (s) => s.replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
