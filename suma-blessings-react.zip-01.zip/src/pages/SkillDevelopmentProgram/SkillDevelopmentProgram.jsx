import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './SkillDevelopmentProgram.css';

export default function SkillDevelopmentProgram() {
  return (
    <>
      <PageBanner title="Skill Development" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Empowering skills, creating opportunities</h2>
            <p>We equip underserved communities with practical skills, vocational training and livelihood opportunities for a brighter future.</p>
            <p>Programmes include Suma Care (General Duty Assistant training) and Silai Se Samriddhi.</p>
            <ul className="ip-list">
              <li>Vocational training</li>
              <li>GDA training initiative</li>
              <li>Tailoring courses</li>
              <li>Placement and livelihood support</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
