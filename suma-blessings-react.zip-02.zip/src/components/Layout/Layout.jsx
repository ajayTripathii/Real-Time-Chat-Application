import { Outlet, useLocation } from 'react-router-dom';
import Header from '../Header/Header';
import Footer from '../Footer/Footer';
import WhatsAppChat from '../WhatsAppChat/WhatsAppChat';
import ScrollToTop from '../ScrollToTop/ScrollToTop';
import DonateModal from '../DonateModal/DonateModal';
import './Layout.css';

export default function Layout() {
  const { pathname } = useLocation();
  return (
    <div className="layout">
      <Header />
      <main className="layout-main page-fade" key={pathname}><Outlet /></main>
      <Footer />
      <WhatsAppChat />
      <ScrollToTop />
      <DonateModal />
    </div>
  );
}
