import { useSearchParams, Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import CauseCard from '../../components/AppealsSection/CauseCard';
import { causes, categories } from '../../data/siteData';
import '../../components/AppealsSection/AppealsSection.css';
import './Campaigns.css';

export default function Campaigns() {
  const [params] = useSearchParams();
  const cat = params.get('category');
  const list = cat ? causes.filter((c) => c.category === cat) : causes;
  return (
    <>
      <PageBanner title="Campaigns" />
      <section className="section alt">
        <div className="container">
          <div className="cp-filters">
            <Link to="/cause" className={!cat ? 'on' : ''}>All</Link>
            {categories.map((c) => (<Link key={c.name} to={`/cause?category=${encodeURIComponent(c.name)}`} className={cat === c.name ? 'on' : ''}>{c.name}</Link>))}
          </div>
          {list.length ? <div className="grid ap-grid">{list.map((c) => <CauseCard key={c.slug} c={c} />)}</div> : <p className="center">No campaigns found in this category right now.</p>}
        </div>
      </section>
    </>
  );
}
