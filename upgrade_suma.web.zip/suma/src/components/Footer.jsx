import { Link } from 'react-router-dom'
import { Phone, Mail, Facebook, Instagram, Twitter, Linkedin, Youtube, Heart, MessageCircle, ArrowUp } from 'lucide-react'
import { contact, social, festivals, occasions } from '../data'
import './Footer.css'
const ic={facebook:Facebook,instagram:Instagram,twitter:Twitter,linkedin:Linkedin,youtube:Youtube}
const cols=[['About Us',[['About Suma Blessings','/about'],['Legal Status','/our-legal-status'],['Our Journey','/our-journey']]],
['Our Projects',[['Suma Vidyalaya','/projects/suma-vidyalaya'],['Silai se Samriddhi','/projects/silai-se-samriddhi'],['Suma Aarogya Raah','/projects/suma-aarogya-raah'],['Suma Spoon of love','/projects/suma-spoon-of-love']]],
['Get Involved',[['Corporate Partnership','/corporate-partnership'],['School Partnership','/school-partnerships'],['Support a Cause','/cause'],['Membership','/become-a-member'],['Careers','/career']]],
['Resource Center',[['The Suma Blog','/news'],['Our events','/events'],['Newsletter','/newsletter'],['Annual Report','/annual-reports'],['Stories of Change','/stories-of-change']]]]
export default function Footer(){
  return (<footer className="ft">
    <div className="container">
      <div className="counters">{[['528','Total Donate Members'],['23','Total Causes'],['₹ 2052400.00','Donation Raised']].map(([n,l])=><div key={l}><h3>{n}</h3><p>{l}</p></div>)}
        <Link to="/cause" className="btn light"><Heart size={16}/> Support a Cause</Link></div>
      <div className="grid g4 cols">{cols.map(([h,ls])=><div key={h}><h4>{h}</h4>{ls.map(([l,p])=><Link key={p} to={p}>{l}</Link>)}</div>)}</div>
      <div className="chips"><h4>Festive Occasion</h4><p>Donate joy on the days that matter most.</p>{festivals.slice(0,14).map(f=><Link key={f[2]} to={f[2]}>{f[1]}</Link>)}</div>
      <div className="chips"><h4>Special Occasion</h4><p>Mark milestones with a meaningful gift.</p>{occasions.map(o=><Link key={o[1]} to={o[1]}>{o[0]}</Link>)}</div>
      <div className="conn"><div><h4>Connect with us</h4><p>Donations to Suma Blessings Foundation are tax exempted under section 80G.</p>
        <a href={`tel:${contact.phone}`}><Phone size={15}/> {contact.phone}</a><a href={`mailto:${contact.email}`}><Mail size={15}/> {contact.email}</a></div>
        <div><h4>Follow us on Social Media</h4><div className="soc">{social.map(([k,u])=>{const I=ic[k];return <a key={k} href={u} target="_blank" rel="noreferrer" aria-label={k}><I size={18}/></a>})}</div></div>
        <div><h4>Subscribe to our newsletter</h4><form onSubmit={e=>{e.preventDefault();alert('Thanks for subscribing!');e.target.reset()}}><input type="email" required placeholder="Email Address"/><button className="btn">Subscribe</button></form></div></div>
      <p className="disc"><b>Disclaimer:</b> Children's information, including images, videos and testimonials, is used with valid consent to raise awareness for the charitable cause.</p>
    </div>
    <div className="copy"><div className="container row2"><span>Copyright © 2026 | All Rights Reserved to Suma Blessings Foundation.</span>
      <span><Link to="/privacy-policy">Privacy & Policy</Link><Link to="/terms-and-condition">Terms & Condition</Link><Link to="/refund-policy">Refund Policy</Link></span></div></div>
    <a className="wa" href="https://api.whatsapp.com/send?phone=917065081060" target="_blank" rel="noreferrer" aria-label="WhatsApp"><MessageCircle/></a>
    <button className="up" onClick={()=>scrollTo({top:0,behavior:'smooth'})} aria-label="Top"><ArrowUp size={18}/></button>
  </footer>)
}
