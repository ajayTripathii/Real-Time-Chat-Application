import { Link } from 'react-router-dom';
import { blogs } from '../../data/siteData';
import BlogCard from './BlogCard';
import './BlogSection.css';

export default function BlogSection() {
  return (
    <section className="section">
      <div className="container">
        <div className="sec-head">
          <span className="eyebrow">News & blogs</span>
          <h2>Our Latest News and Blogs</h2>
          <p>Get the Latest News and Blog information here and be connected with us Always</p>
        </div>
        <div className="grid bg-grid">{blogs.map((b) => <BlogCard key={b.slug} b={b} />)}</div>
        <div className="center mt"><Link to="/news" className="btn">Read all articles</Link></div>
      </div>
    </section>
  );
}
