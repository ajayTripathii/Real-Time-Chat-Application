import { Link } from 'react-router-dom'
import { ArrowRight, BadgeCheck, GraduationCap, HeartPulse, Utensils, Users, Wrench, Leaf, Megaphone, FlaskConical, Calendar, MapPin, ShieldCheck } from 'lucide-react'
import Slider from '../components/Slider'
import Img from '../components/Img'
import { slides, categories, whatWeDo, stats, projects, appeals, involve, festivals, occasions, events, news } from '../data'
import './Home.css'
const icons=[GraduationCap,HeartPulse,Utensils,Users,Wrench,Leaf,Megaphone,FlaskConical]
export default function Home(){
  return (<div className="home">
    <Slider slides={slides}/>
    <section className="section"><div className="container"><div className="cats">
      {categories.map((c,i)=><Link key={c} to={`/cause?category=${encodeURIComponent(c)}`} className="cat reveal" style={{transitionDelay:i*70+'ms'}}><div className="ci"><Img name={`c${i+1}.jpg`}/></div><h4>{c}</h4></Link>)}
    </div></div></section>
    <section className="section alt"><div className="container two">
      <div className="reveal"><span className="eyebrow">Registered NGO</span><h2 className="title">12A & 80G Certified non-profit charity organization</h2>
        <p className="lead">Donate for a good cause and claim 50% tax exemption under section 80G of the Income Tax Act.</p>
        <div className="ticks">{['12A registered','80G tax benefit','CSR ready'].map(t=><span key={t}><BadgeCheck size={18}/>{t}</span>)}</div></div>
      <div className="wwd">{whatWeDo.map(([l,p],i)=>{const I=icons[i];return <Link key={l} to={p} className="reveal"><I size={26}/><b>{l}</b><small>Learn more <ArrowRight size={13}/></small></Link>})}</div>
    </div></section>
    <section className="section"><div className="container center reveal"><span className="eyebrow">We are committing to</span><h2 className="title">Sustainable Development Goals</h2>
      <div className="sdg">{Array.from({length:17},(_,i)=><span key={i} style={{background:`hsl(${i*21},65%,45%)`}}>{i+1}</span>)}</div></div></section>
    <section className="section alt"><div className="container two">
      <div className="aboutimg reveal"><Img name="about.jpg" alt="About Suma Blessings Foundation"/><div className="badge"><b>1M+</b>People benefited through our programmes</div></div>
      <div className="reveal"><span className="eyebrow">About us</span><h2 className="title">About Suma Blessings Foundation</h2>
        <p className="lead">Established in 2021, Suma Blessings Foundation is a not-for-profit organization committed to the holistic development of marginalized communities.</p>
        <div className="ticks">{['Education','Healthcare','Community'].map(t=><span key={t}><BadgeCheck size={18}/>{t}</span>)}</div>
        <Link to="/about" className="btn">Learn more <ArrowRight size={18}/></Link></div></div>
      <div className="container stats">{stats.map(([n,l])=><div key={l} className="reveal"><h3>{n}</h3><p>{l}</p></div>)}</div></section>
    <section className="csr"><div className="container reveal"><span className="eyebrow" style={{color:'#ffd8b8'}}>Partnership & CSR</span><h2 className="title">Your Corporate Social Responsibility Starts Here</h2>
      <p className="lead">Explore curated CSR programs that match your company's goals while uplifting the underprivileged.</p>
      <div className="ticks w">{['80G tax benefit','CSR-ready programmes','Transparent reporting'].map(t=><span key={t}><ShieldCheck size={18}/>{t}</span>)}</div>
      <Link to="/csr" className="btn light">Accelerate Your CSR Goals</Link> <Link to="/contact" className="btn ghost w">Talk to our team</Link></div></section>
    <section className="section"><div className="container"><div className="head"><div><span className="eyebrow">On the ground</span><h2 className="title">Our Impact Projects</h2><p className="lead">Transforming lives through meaningful projects that inspire hope, dignity and long-term impact.</p></div><Link to="/projects" className="btn ghost">Show all projects</Link></div>
      <div className="grid g3">{projects.map(p=><Link key={p.path} to={p.path} className="card reveal"><div className="img"><Img name={p.img}/></div><div className="body"><h3>{p.name}</h3><p>{p.sub}</p>{p.facts&&<ul className="facts">{p.facts.map(f=><li key={f}>{f}</li>)}</ul>}<span className="more">View project <ArrowRight size={15}/></span></div></Link>)}</div></div></section>
    <section className="section alt"><div className="container"><div className="head"><div><span className="eyebrow">Verified causes • Tax benefit eligible</span><h2 className="title">Recent Appeals – Pick a cause close to your heart</h2></div><Link to="/cause" className="btn ghost">Find all causes</Link></div>
      <div className="grid g4">{appeals.map(a=><Link key={a.path} to={a.path} className="card reveal"><div className="img"><Img name={a.img}/><span className="tb">Tax benefit</span></div><div className="body"><h3>{a.title}</h3><div className="bar"><i style={{width:Math.max(a.pct,1)+'%'}}/></div><small>{a.pct}% • Raised {a.raised} • Goal {a.goal}</small><span className="btn sm">Support this cause</span></div></Link>)}</div></div></section>
    <section className="section"><div className="container center"><span className="eyebrow">Get involved</span><h2 className="title">Be Part of our Team</h2><p className="lead">Join us and create positive change with passion and purpose.</p>
      <div className="grid g3 left">{involve.map(x=><div key={x.t} className="card reveal"><div className="img"><Img name={x.img}/></div><div className="body"><h3>{x.t}</h3><p>{x.d}</p><Link to={x.p} className="btn sm">Apply now</Link></div></div>)}</div></div></section>
    <section className="section alt"><div className="container"><span className="eyebrow">Celebrate & give</span><h2 className="title">Donate on Indian Festive Occasion</h2><p className="lead">Spread joy this festive season by giving back to those in need.</p>
      <div className="fest">{festivals.map(([d,t,p])=><Link key={p} to={p} className="reveal"><em>{d}</em><b>{t}</b></Link>)}</div><Link to="/all-festivals" className="btn">View all festivals</Link></div></section>
    <section className="section"><div className="container"><span className="eyebrow">Mark a milestone</span><h2 className="title">Special Occasion Donation</h2><p className="lead">Make a donation in honor of your loved ones.</p>
      <div className="grid g3">{occasions.map(([t,p,im])=><Link key={p} to={p} className="card occ reveal"><div className="img"><Img name={im}/></div><h3>{t}</h3></Link>)}</div></div></section>
    <section className="section alt"><div className="container"><div className="head"><div><span className="eyebrow">Our Latest and Upcoming Events</span><h2 className="title">Stay connected for our latest events</h2></div><Link to="/events" className="btn ghost">View all events</Link></div>
      <div className="grid g3">{events.slice(0,3).map(e=><Link key={e.p} to={e.p} className="card reveal"><div className="img"><Img name={e.img}/><span className="tb">{e.d}</span></div><div className="body"><h3>{e.t}</h3><small><MapPin size={13}/> {e.loc}</small></div></Link>)}</div></div></section>
    <section className="section"><div className="container"><span className="eyebrow">News & blogs</span><h2 className="title">Our Latest News and Blogs</h2>
      <div className="grid g4">{news.slice(0,4).map(n=><Link key={n.p} to={n.p} className="card reveal"><div className="img"><Img name={n.img}/></div><div className="body"><small><Calendar size={13}/> {n.d} • by Team</small><h3>{n.t}</h3></div></Link>)}</div></div></section>
  </div>)
}
