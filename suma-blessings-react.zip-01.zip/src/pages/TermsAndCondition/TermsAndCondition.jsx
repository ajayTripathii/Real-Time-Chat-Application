import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './TermsAndCondition.css';

export default function TermsAndCondition() {
  return (
    <>
      <PageBanner title="Terms & Conditions" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Rules of using this website</h2>
            <p>By using this website you agree to these terms. Donations are voluntary and used for the stated charitable purposes.</p>
            <p>Add your full terms and conditions text here.</p>
            <ul className="ip-list">
              <li>Use of the website</li>
              <li>Donation terms</li>
              <li>Intellectual property</li>
              <li>Limitation of liability</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
