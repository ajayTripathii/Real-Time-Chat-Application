import { useParams, Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import { blogs, titleCase } from '../../data/siteData';
import './NewsDetail.css';

export default function NewsDetail() {
  const { slug } = useParams();
  const b = blogs.find((x) => x.slug === slug);
  const title = b ? b.title : titleCase(slug);
  return (
    <>
      <PageBanner title={title} crumbs={[['The Suma Blog', '/news']]} />
      <section className="section">
        <div className="container nd-wrap">
          {b && <img src={b.img} alt={b.title} className="nd-img" />}
          <p className="nd-meta">by Team • {b?.date}</p>
          <h2>{title}</h2>
          <p>Giving is more meaningful when it reaches the people who need it most. At Suma Blessings Foundation, every article, campaign and celebration is rooted in our mission of holistic development for marginalized communities.</p>
          <p>Add the full article content for this post here, or connect it to your CMS / API when the backend is ready.</p>
          <Link to="/news" className="btn outline mt">← All articles</Link>
        </div>
      </section>
    </>
  );
}
