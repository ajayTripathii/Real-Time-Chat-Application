import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './AnnualReports.css';

export default function AnnualReports() {
  return (
    <>
      <PageBanner title="Annual Reports" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Transparency you can read</h2>
            <p>Our annual reports summarise programmes, impact numbers and financials.</p>
            <p>Add downloadable PDF reports for each year here.</p>
            <ul className="ip-list">
              <li>Programme highlights</li>
              <li>Impact data</li>
              <li>Financial statements</li>
              <li>Donor acknowledgements</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
