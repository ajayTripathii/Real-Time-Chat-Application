import { useState } from 'react'
import { Phone, Mail, MapPin, Send } from 'lucide-react'
import { contact } from '../data'
import './Contact.css'
export default function Contact(){
  const [ok,setOk]=useState(false)
  return (<><div className="page-hero"><small>Get in touch</small><h1>Contact Us</h1></div>
  <section className="section"><div className="container ct">
    <div className="reveal info">{[[Phone,'Phone',contact.phone],[Mail,'Email',contact.email],[MapPin,'Address',contact.addr]].map(([I,t,v])=><div key={t}><I/><span><b>{t}</b>{v}</span></div>)}</div>
    <form className="reveal" onSubmit={e=>{e.preventDefault();setOk(true);e.target.reset()}}>
      <input required placeholder="Your Name"/><input required type="email" placeholder="Email"/><input placeholder="Phone"/><textarea required rows="5" placeholder="Message"/>
      <button className="btn"><Send size={16}/> Send Message</button>{ok&&<p className="ok">Thank you! We will contact you soon.</p>}</form></div></section></>)
}
