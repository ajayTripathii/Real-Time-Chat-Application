import PageBanner from '../../components/PageBanner/PageBanner';
import EventsSection from '../../components/EventsSection/EventsSection';
import './Events.css';

export default function Events() {
  return (<><PageBanner title="Workshops & Events" /><div className="events-page"><EventsSection showHead={false} /></div></>);
}
