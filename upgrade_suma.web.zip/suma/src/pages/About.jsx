import { Link } from 'react-router-dom'
import { BadgeCheck } from 'lucide-react'
import Img from '../components/Img'
import { stats } from '../data'
import './About.css'
export default function About(){
  return (<><div className="page-hero"><small>About Us</small><h1>About Suma Blessings Foundation</h1></div>
  <section className="section"><div className="container ab">
    <div className="reveal"><Img name="about.jpg"/></div>
    <div className="reveal"><span className="eyebrow">Who we are</span><h2 className="title">Holistic development of marginalized communities</h2>
      <p className="lead">Established in 2021, Suma Blessings Foundation is a not-for-profit organization working in education, healthcare and community development.</p>
      {['Education','Healthcare','Community'].map(t=><p key={t} className="tk"><BadgeCheck size={18}/> {t}</p>)}
      <Link to="/mission-vision" className="btn">Mission & Vision</Link></div></div>
    <div className="container as">{stats.map(([n,l])=><div key={l} className="reveal"><h3>{n}</h3><p>{l}</p></div>)}</div></section></>)
}
