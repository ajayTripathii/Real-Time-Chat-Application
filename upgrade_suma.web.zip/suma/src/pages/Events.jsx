import { Link } from 'react-router-dom'
import { MapPin, Calendar } from 'lucide-react'
import Img from '../components/Img'
import { events } from '../data'
import './Events.css'
export default function Events(){
  return (<><div className="page-hero"><small>Media</small><h1>Workshops & Events</h1></div>
  <section className="section"><div className="container ev">{events.map(e=><Link key={e.p} to={e.p} className="card reveal"><div className="img"><Img name={e.img}/></div><div className="body"><small><Calendar size={13}/> {e.d}</small><h3>{e.t}</h3><small><MapPin size={13}/> {e.loc}</small></div></Link>)}</div></section></>)
}
