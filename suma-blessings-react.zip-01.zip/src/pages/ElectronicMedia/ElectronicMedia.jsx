import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './ElectronicMedia.css';

export default function ElectronicMedia() {
  return (
    <>
      <PageBanner title="Electronic Media" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>On television, radio and digital platforms</h2>
            <p>Watch and listen to our appearances on electronic media.</p>
            <p>Add TV, radio and podcast links here.</p>
            <ul className="ip-list">
              <li>TV coverage</li>
              <li>Radio interviews</li>
              <li>Podcasts</li>
              <li>YouTube features</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
