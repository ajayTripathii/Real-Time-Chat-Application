import { useEffect } from 'react';
import './Lightbox.css';

export default function Lightbox({ items, index, onClose, onChange }) {
  const n = items.length;
  useEffect(() => {
    const key = (e) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') onChange((index + 1) % n);
      if (e.key === 'ArrowLeft') onChange((index - 1 + n) % n);
    };
    window.addEventListener('keydown', key);
    document.body.style.overflow = 'hidden';
    return () => { window.removeEventListener('keydown', key); document.body.style.overflow = ''; };
  }, [index, n, onClose, onChange]);
  const [src, cap] = items[index];
  return (
    <div className="lb" onClick={onClose} role="dialog" aria-modal="true">
      <button className="lb-x" onClick={onClose} aria-label="Close">✕</button>
      <button className="lb-a l" onClick={(e) => { e.stopPropagation(); onChange((index - 1 + n) % n); }} aria-label="Previous">‹</button>
      <figure onClick={(e) => e.stopPropagation()}><img src={src} alt={cap} /><figcaption>{cap} · {index + 1} / {n}</figcaption></figure>
      <button className="lb-a r" onClick={(e) => { e.stopPropagation(); onChange((index + 1) % n); }} aria-label="Next">›</button>
    </div>
  );
}
