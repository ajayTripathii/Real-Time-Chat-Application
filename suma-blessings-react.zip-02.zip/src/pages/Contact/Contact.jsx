import { useState } from 'react';
import PageBanner from '../../components/PageBanner/PageBanner';
import { PHONE, EMAIL, ADDRESS } from '../../data/siteData';
import { useToast } from '../../context/ToastContext';
import './Contact.css';

export default function Contact() {
  const [sent, setSent] = useState(false);
  const toast = useToast();
  return (
    <>
      <PageBanner title="Contact Us" />
      <section className="section">
        <div className="container ct-grid">
          <div className="ct-info">
            <span className="eyebrow">Get in touch</span>
            <h2>We'd love to hear from you</h2>
            <p>Questions about donations, volunteering, CSR or our programmes? Write to us and our team will reply shortly.</p>
            <ul>
              <li><b>📍 Address</b><span>{ADDRESS}</span></li>
              <li><b>📞 Phone</b><a href="tel:+919971759656">{PHONE}</a></li>
              <li><b>✉️ Email</b><a href={`mailto:${EMAIL}`}>{EMAIL}</a></li>
            </ul>
          </div>
          <form className="card ct-form" onSubmit={(e) => { e.preventDefault(); setSent(true); toast('Message sent. We will contact you soon.'); }}>
            {sent ? <div className="thanks">Thank you! Your message has been sent. We will contact you soon.</div> : (
              <div className="form-grid">
                <div className="field"><label>Name</label><input required placeholder="Your name" /></div>
                <div className="field"><label>Email</label><input type="email" required placeholder="you@email.com" /></div>
                <div className="field"><label>Phone</label><input type="tel" placeholder="Mobile number" /></div>
                <div className="field"><label>Subject</label><input required placeholder="Subject" /></div>
                <div className="field full"><label>Message</label><textarea rows="5" required placeholder="How can we help?" /></div>
                <div className="full"><button className="btn">Send Message</button></div>
              </div>
            )}
          </form>
        </div>
        <div className="container ct-map">
          <iframe title="Suma Blessings location" loading="lazy" src="https://www.google.com/maps?q=Baprola+Road+Najafgarh+New+Delhi&output=embed" />
        </div>
      </section>
    </>
  );
}
