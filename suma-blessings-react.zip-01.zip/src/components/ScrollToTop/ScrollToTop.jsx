import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import './ScrollToTop.css';

export default function ScrollToTop() {
  const { pathname, search } = useLocation();
  const [show, setShow] = useState(false);
  useEffect(() => { window.scrollTo(0, 0); }, [pathname, search]);
  useEffect(() => {
    const on = () => setShow(window.scrollY > 500);
    window.addEventListener('scroll', on);
    return () => window.removeEventListener('scroll', on);
  }, []);
  return <button className={`stt ${show ? 'show' : ''}`} onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} aria-label="Back to top">↑</button>;
}
