import PageBanner from '../../components/PageBanner/PageBanner';
import Reveal from '../../components/Reveal/Reveal';
import { md } from '../../utils/md';
import './OurJourney.css';

const J = 'https://www.sumablessings.org/assets/images/frontend/journey/';
const steps = [
  { year: '2026 - A Journey of Skills, Empowerment and Opportunity', img: '6ac230d739ecb1791111383.jpg', points: [
    '**Established a Skill Development Training Center in Sector 3, Noida, Uttar Pradesh**, providing women and youth with opportunities to develop practical, employment-oriented skills and enhance their career prospects.',
    'We also established a **Women Empowerment Training Center in Baprola Village, Dwarka**, offering skill-based programs in **Candle Making, Art & Craft, and other creative livelihood activities**. These programs are designed to help women develop marketable skills, explore entrepreneurship, and create sustainable sources of income.'],
    note: 'Through these initiatives, we are working to **build confidence, strengthen skills, promote entrepreneurship, and create pathways toward sustainable livelihoods and financial independence** for women and youth.' },
  { year: '2025 – Scaling Up and Digital Empowerment', img: '686a9fa65b6ee1751818150.jpg', points: [
    'Initiated pilots for **two new Suma Vidyalaya Educational Centres** in Haryana and Greater Noida, based on local need assessments.',
    'In the verge to launch a **Digital Skilling Centre** in Dwarka Sector 16A, aimed at equipping youth with employable digital skills for sustainable livelihoods.',
    'Marked World Environment Day with the **planting of 1,000 trees** in a major community park in Dwarka Sector 12.',
    'Continued **food and nutrition support drives** in urban poor communities.',
    'Initiated partnership with Tata Projects to facilitate volunteering initiatives and community engagement.',
    'Collaborated with Connecting Dreams Foundation to launch a women-led livelihood initiative, enabling local women to form production groups for income generation.'] },
  { year: '2024 – Deeper Community Integration and Advocacy', img: '686a9ef4a88dd1751817972.jpg', points: [
    'Launched our **third Suma Vidyalaya in Dwarka Sector 16A**, New Delhi.',
    'Continued long-term medical support for Souray and onboarded Galib, a young blood cancer patient, covering treatment and nutritional needs.',
    'Expanded health and hygiene awareness initiatives, including sanitary pad distributions and menstrual health sessions.',
    'Partnered with a reputed oncologist from **Max Healthcare** to conduct breast cancer awareness sessions for women in Sector 16A.',
    'Conducted **plantation drives in Dwarka and Uttam Nagar** to strengthen environmental stewardship.',
    'Celebrated our 3rd Annual Day, featuring large-scale community engagement and collaboration with the Secretary of MCD, Dwarka.',
    'Organized nutrition food camps benefiting families during the Annual Day celebrations.'] },
  { year: '2023 – Expansion and Healthcare Collaboration', img: '686a9e070ad701751817735.jpg', points: [
    'Established our second **Suma Vidyalaya** – Community Centre in **Uttam Nagar, Delhi,** extending educational and community services to urban marginalized groups.',
    'Provided on-going medical support to Souray, a child from a vulnerable community diagnosed with congenital heart defect and tuberculosis.',
    'Organized maternal and **childcare awareness camps** in underserved areas of Dwarka and Uttam Nagar.',
    'Conducted **blanket distribution drives** for the homeless near temples and shrines.',
    'Initiated **plantation drives** to promote urban environmental sustainability across sectors in Dwarka.'] },
  { year: '2022 – Initial Outreach and Grassroots Engagement', img: '686a69272cd4d1751804199.jpg', points: [
    'Launched our first community-based education Centre, **Suma Vidyalaya, in Balasore, Odisha**.',
    'Conducted multiple health and awareness camps focusing on hygiene, general well-being, and community health in rural Odisha.',
    'Rolled out women empowerment and livelihood generation programs, targeting self sufficiency for local women.',
    'Carried out emergency dry ration distribution and cooked meal drives during the COVID-19 pandemic, supporting families in crisis.'] },
  { year: '2021 - Formally registered as a not-for-profit organization. 12A and 80G.', img: '686abd05bf44d1751825669.jpg', points: [
    'Suma Blessings Foundation was formally **registered in 2021 as a not-for-profit organization** with a mission to uplift marginalized communities through holistic development programs.',
    'Carried out emergency dry ration distribution and cooked meal drives **during the COVID-19 pandemic**, supporting families in crisis.'] },
];

export default function OurJourney() {
  return (
    <>
      <PageBanner title="Our Journey" />
      <section className="section">
        <div className="container center">
          <span className="eyebrow">Our story</span>
          <h2>Our Journey: Suma Blessings Foundation</h2>
          <p className="oj-lead">Suma Blessings Foundation was formally registered in 2021 as a not-for-profit organization with a mission to uplift marginalized communities through holistic development programs.</p>
          <ul className="oj-pills"><li>Impact-led</li><li>Community-first</li><li>Hope in action</li></ul>
        </div>
      </section>
      <section className="section alt">
        <div className="container oj-line">
          {steps.map((s, i) => (
            <Reveal key={s.year}>
              <article className={`oj-item ${i % 2 ? 'odd' : ''}`}>
                <span className="oj-num">{String(i + 1).padStart(2, '0')}</span>
                <img src={J + s.img} alt={s.year} loading="lazy" />
                <div>
                  <h3>{s.year}</h3>
                  <ul className="ip-list">{s.points.map((p) => <li key={p}>{md(p)}</li>)}</ul>
                  {s.note && <p>{md(s.note)}</p>}
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </section>
    </>
  );
}
