import { Link } from 'react-router-dom';
import { inr } from '../../data/siteData';

export default function CauseCard({ c }) {
  const fmt = (n) => (c.meals ? `${Number(n).toLocaleString('en-IN')} Meal(s)` : inr(n));
  return (
    <article className="card ap-card">
      <Link to={`/cause/${c.slug}`} className="ap-img">
        <img src={c.img} alt={c.title} loading="lazy" />
        <span className="ap-tax">Tax benefit</span>
      </Link>
      <div className="ap-body">
        <h3><Link to={`/cause/${c.slug}`}>{c.title.length > 85 ? c.title.slice(0, 85) + '...' : c.title}</Link></h3>
        {c.details && <dl>{c.details.map(([k, v]) => (<div key={k}><dt>{k}</dt><dd>{v}</dd></div>))}</dl>}
        <div className="ap-bar"><i style={{ width: `${Math.max(c.pct, 1)}%` }}><span>{c.pct}%</span></i></div>
        <div className="ap-nums"><span>Raised <b>{fmt(c.raised)}</b></span><span>Goal <b>{fmt(c.goal)}</b></span></div>
        <Link to={`/cause/${c.slug}`} className="btn sm">Support this cause</Link>
      </div>
    </article>
  );
}
