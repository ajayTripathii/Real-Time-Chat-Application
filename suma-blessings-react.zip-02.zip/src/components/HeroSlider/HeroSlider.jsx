import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { heroSlides } from '../../data/siteData';
import './HeroSlider.css';

export default function HeroSlider() {
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const n = heroSlides.length;
  useEffect(() => {
    if (paused) return undefined;
    const t = setInterval(() => setI((p) => (p + 1) % n), 5500);
    return () => clearInterval(t);
  }, [n, paused]);
  return (
    <section className="hs" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
      {heroSlides.map((s, k) => (
        <div key={k} className={`hs-slide ${k === i ? 'on' : ''}`} style={{ backgroundImage: `linear-gradient(90deg, rgba(8,28,46,0.9) 0%, rgba(8,28,46,0.55) 55%, rgba(8,28,46,0.2) 100%), url(${s.img})` }}>
          <div className="container hs-in">
            <span className="hs-tag">{s.tag}</span>
            <h2>{s.title}</h2>
            <Link to={s.to} className="btn">Read More</Link>
          </div>
        </div>
      ))}
      <button className="hs-arrow l" onClick={() => setI((i - 1 + n) % n)} aria-label="Previous">‹</button>
      <button className="hs-arrow r" onClick={() => setI((i + 1) % n)} aria-label="Next">›</button>
      <div className="hs-dots">{heroSlides.map((_, k) => <button key={k} className={k === i ? 'on' : ''} onClick={() => setI(k)} aria-label={`Slide ${k + 1}`} />)}</div>
    </section>
  );
}
