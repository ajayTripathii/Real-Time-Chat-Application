import { useState } from 'react'
import { Heart, ShieldCheck } from 'lucide-react'
import './Donate.css'
export default function Donate(){
  const [amt,setAmt]=useState(1000),[done,setDone]=useState(false)
  return (<><div className="page-hero"><small>80G eligible</small><h1>Donate Now</h1></div>
  <section className="section"><div className="container dn reveal">
    <h3>You are donating for</h3><div className="amts">{[500,1000,2500,5000].map(a=><button key={a} className={a===amt?'on':''} onClick={()=>setAmt(a)}>₹{a}</button>)}</div>
    <input type="number" min="1" value={amt} onChange={e=>setAmt(+e.target.value)}/>
    <p className="tot">Total Amount <b>₹{(amt||0).toFixed(2)}</b></p>
    <button className="btn" onClick={()=>setDone(true)}><Heart size={16}/> Proceed to Donate</button>
    <p className="tx"><ShieldCheck size={16}/> Donations may be eligible for tax benefit under Section 80G.</p>{done&&<p className="tx">Payment gateway integration goes here.</p>}</div></section></>)
}
