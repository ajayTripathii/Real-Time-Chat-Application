import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './FoodNutrition.css';

export default function FoodNutrition() {
  return (
    <>
      <PageBanner title="Food & Nutrition" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Because no child should sleep hungry</h2>
            <p>Through Suma Spoon of Love we have distributed over 1 million meals and delivered 1800+ ration kits to 30+ communities.</p>
            <p>Our nutrition drives focus on children, women and the elderly.</p>
            <ul className="ip-list">
              <li>Cooked meal distribution</li>
              <li>Ration kit delivery</li>
              <li>Festival food drives</li>
              <li>Sponsor-a-meal campaigns</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
