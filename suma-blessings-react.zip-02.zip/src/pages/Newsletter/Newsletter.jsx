import { useState } from 'react';
import PageBanner from '../../components/PageBanner/PageBanner';
import { useToast } from '../../context/ToastContext';
import './Newsletter.css';

const fields = [["Full name", "text"], ["Email", "email"]];

export default function Newsletter() {
  const [sent, setSent] = useState(false);
  const toast = useToast();
  return (
    <>
      <PageBanner title="Newsletter" />
      <section className="section alt">
        <div className="container fm-wrap">
          <div className="fm-intro">
            <h2>Newsletter</h2>
            <p>Subscribe and don't miss any update from Suma Blessings Foundation.</p>
          </div>
          <form className="card fm-card" onSubmit={(e) => { e.preventDefault(); setSent(true); toast('Submitted successfully. We will contact you soon.'); }}>
            {sent ? <div className="thanks">Thank you! We have received your details and will contact you soon.</div> : (
              <div className="form-grid">
                {fields.map(([label, type]) => (
                  <div className="field" key={label}><label>{label}</label><input type={type} required /></div>
                ))}
                <div className="field full"><label>Message (optional)</label><textarea rows="4" /></div>
                <div className="full"><button className="btn">Subscribe</button></div>
              </div>
            )}
          </form>
        </div>
      </section>
    </>
  );
}
