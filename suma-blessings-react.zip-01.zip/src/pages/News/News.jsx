import PageBanner from '../../components/PageBanner/PageBanner';
import BlogCard from '../../components/BlogSection/BlogCard';
import { blogs } from '../../data/siteData';
import '../../components/BlogSection/BlogSection.css';
import './News.css';

export default function News() {
  return (
    <>
      <PageBanner title="The Suma Blog" />
      <section className="section"><div className="container"><div className="grid bg-grid">{blogs.map((b) => <BlogCard key={b.slug} b={b} />)}</div></div></section>
    </>
  );
}
