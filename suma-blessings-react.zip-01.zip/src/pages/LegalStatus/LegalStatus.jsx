import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './LegalStatus.css';

export default function LegalStatus() {
  return (
    <>
      <PageBanner title="Legal Status" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>A registered, tax-exempt charitable organization</h2>
            <p>Suma Blessings Foundation is a registered NGO with 12A registration and 80G certification, allowing donors to claim tax benefits under the Income Tax Act.</p>
            <p>Our CSR-ready structure and transparent reporting make us a trusted partner for corporates and individuals.</p>
            <ul className="ip-list">
              <li>12A registered</li>
              <li>80G tax benefit (50% exemption)</li>
              <li>CSR ready</li>
              <li>Annual reports published</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
