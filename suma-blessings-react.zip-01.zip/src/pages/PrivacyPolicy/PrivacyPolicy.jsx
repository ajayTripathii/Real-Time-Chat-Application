import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './PrivacyPolicy.css';

export default function PrivacyPolicy() {
  return (
    <>
      <PageBanner title="Privacy Policy" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>How we handle your information</h2>
            <p>Suma Blessings Foundation respects your privacy. Personal information shared during donation, registration or contact is used only to serve you and meet legal requirements.</p>
            <p>Add your full privacy policy text here.</p>
            <ul className="ip-list">
              <li>Data collected</li>
              <li>How it is used</li>
              <li>Security of information</li>
              <li>Your rights</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
