import { Link } from 'react-router-dom';
import { events } from '../../data/siteData';
import './EventsSection.css';

export default function EventsSection({ showHead = true }) {
  return (
    <section className="section alt">
      <div className="container">
        {showHead && (
          <div className="sec-head">
            <span className="eyebrow">Our Latest and Upcoming Events</span>
            <h2>Stay connected for our Latest and upcoming events</h2>
            <p>Join drives, celebrations, and community programmes. See what is happening on the ground and how you can take part.</p>
            <ul className="ev-badges"><li>Dates & timings</li><li>Venues & locations</li><li>Community gatherings</li></ul>
          </div>
        )}
        <ul className="ev-list">
          {events.map((e) => (
            <li key={e.slug} className="ev-item">
              <span className="ev-date"><b>{e.day}</b>{e.mon}</span>
              <div className="ev-body">
                <h3><Link to={`/events/${e.slug}`}>{e.title}</Link></h3>
                <p>{e.text}</p>
                <ul className="ev-meta">{e.time && <li>🕒 {e.time}</li>}{e.venue && <li>📍 {e.venue}</li>}</ul>
              </div>
              <Link to={`/events/${e.slug}`} className="btn outline sm">View event details</Link>
            </li>
          ))}
        </ul>
        {showHead && <div className="center mt"><Link to="/events" className="btn">View all events</Link></div>}
      </div>
    </section>
  );
}
