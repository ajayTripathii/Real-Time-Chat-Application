import { useState } from 'react';
import PageBanner from '../../components/PageBanner/PageBanner';
import './Career.css';

const fields = [["Full name", "text"], ["Email", "email"], ["Mobile", "tel"], ["Position applying for", "text"], ["Experience (years)", "number"]];

export default function Career() {
  const [sent, setSent] = useState(false);
  return (
    <>
      <PageBanner title="Work with Us" />
      <section className="section alt">
        <div className="container fm-wrap">
          <div className="fm-intro">
            <h2>Work with Us</h2>
            <p>Join our team and serve those in need with passion and purpose.</p>
          </div>
          <form className="card fm-card" onSubmit={(e) => { e.preventDefault(); setSent(true); }}>
            {sent ? <div className="thanks">Thank you! We have received your details and will contact you soon.</div> : (
              <div className="form-grid">
                {fields.map(([label, type]) => (
                  <div className="field" key={label}><label>{label}</label><input type={type} required /></div>
                ))}
                <div className="field full"><label>Message (optional)</label><textarea rows="4" /></div>
                <div className="full"><button className="btn">Submit application</button></div>
              </div>
            )}
          </form>
        </div>
      </section>
    </>
  );
}
