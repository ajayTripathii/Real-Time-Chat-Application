import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './Team.css';

export default function Team() {
  return (
    <>
      <PageBanner title="Management Team" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>The team that makes it happen on the ground</h2>
            <p>Our management team coordinates projects, fundraising, volunteers and partnerships across all our centers.</p>
            <p>Add each team member's photo, name and role here.</p>
            <ul className="ip-list">
              <li>Fund-Raising</li>
              <li>Project Co-ordination</li>
              <li>Programme delivery</li>
              <li>Volunteer management</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
