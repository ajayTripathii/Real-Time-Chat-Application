import { Link } from 'react-router-dom';
import './CsrSection.css';

export default function CsrSection() {
  return (
    <section className="csr">
      <div className="container csr-in">
        <span className="eyebrow">Partnership & CSR</span>
        <h2>Your Corporate Social Responsibility Starts Here</h2>
        <p>Explore curated CSR programs that match your company’s goals while uplifting the underprivileged.</p>
        <ul><li>80G tax benefit</li><li>CSR-ready programmes</li><li>Transparent reporting</li></ul>
        <div className="csr-btns">
          <Link to="/csr" className="btn">Accelerate Your CSR Goals</Link>
          <Link to="/contact" className="btn outline">Talk to our team</Link>
        </div>
      </div>
    </section>
  );
}
