import { Link } from 'react-router-dom';
import { involved } from '../../data/siteData';
import './InvolvedSection.css';

export default function InvolvedSection() {
  return (
    <section className="section">
      <div className="container">
        <div className="sec-head">
          <span className="eyebrow">Get involved</span>
          <h2>Be Part of our Team</h2>
          <p>Join our incredible team and make a difference in our community! Together, we can create positive change and serve those in need with passion and purpose.</p>
        </div>
        <div className="grid iv-grid">
          {involved.map((i) => (
            <article key={i.title} className="card iv-card">
              <Link to={i.to} className="iv-img"><img src={i.img} alt={i.title} loading="lazy" /></Link>
              <div className="iv-body">
                <h3><Link to={i.to}>{i.title}</Link></h3>
                <p>{i.text}</p>
                <Link to={i.to} className="btn sm">Apply now</Link>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
