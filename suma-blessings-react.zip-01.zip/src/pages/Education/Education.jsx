import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './Education.css';

export default function Education() {
  return (
    <>
      <PageBanner title="Education" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Learning that opens doors</h2>
            <p>Suma Vidyalaya is a community-based educational center designed to support children from underprivileged backgrounds.</p>
            <p>We provide classroom learning, study material, digital literacy and celebrations that make school a joyful place.</p>
            <ul className="ip-list">
              <li>Free community schooling</li>
              <li>Digital literacy and computer training</li>
              <li>Study kits and uniforms</li>
              <li>AI and skill awareness sessions</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
