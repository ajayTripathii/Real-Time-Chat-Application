import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './SchoolPartnerships.css';

export default function SchoolPartnerships() {
  return (
    <>
      <PageBanner title="School Partnerships" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Teach kindness early</h2>
            <p>Schools can partner with us for donation drives, awareness sessions and student volunteering.</p>
            <p>Students learn the value of giving while helping children in need.</p>
            <ul className="ip-list">
              <li>Birthday and festival drives</li>
              <li>Student volunteering</li>
              <li>Awareness workshops</li>
              <li>Certificates of participation</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
