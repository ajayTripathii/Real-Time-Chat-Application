import { useState } from 'react';
import PageBanner from '../../components/PageBanner/PageBanner';
import { useDonation } from '../../context/DonationContext';
import { inr } from '../../data/siteData';
import './DonateNow.css';

const purposes = ['Where needed most', 'Child Education', 'Food & Nutrition', 'Healthcare', 'Women Empowerment', 'Skill Development', 'Environment'];
const amounts = [500, 1000, 2500, 5000, 10000];

export default function DonateNow() {
  const { add } = useDonation();
  const [purpose, setPurpose] = useState(purposes[0]);
  const [amt, setAmt] = useState(1000);
  return (
    <>
      <PageBanner title="Donate Now" />
      <section className="section alt">
        <div className="container dn-wrap">
          <div className="card dn-card">
            <span className="eyebrow">You are donating for</span>
            <h2>Make a difference today</h2>
            <p className="dn-sub">Donations are eligible for tax benefit under Section 80G.</p>
            <div className="field"><label>Purpose</label><select value={purpose} onChange={(e) => setPurpose(e.target.value)}>{purposes.map((p) => <option key={p}>{p}</option>)}</select></div>
            <div className="dn-amts">{amounts.map((a) => <button type="button" key={a} className={amt === a ? 'on' : ''} onClick={() => setAmt(a)}>{inr(a)}</button>)}</div>
            <div className="field"><label>Custom amount (₹)</label><input type="number" min="1" value={amt} onChange={(e) => setAmt(e.target.value)} /></div>
            <div className="dn-total">Total Amount <b>{inr(amt || 0)}</b></div>
            <button className="btn" onClick={() => amt > 0 && add({ id: `general-${purpose}`, title: purpose, amount: amt })}>Donate Now</button>
          </div>
        </div>
      </section>
    </>
  );
}
