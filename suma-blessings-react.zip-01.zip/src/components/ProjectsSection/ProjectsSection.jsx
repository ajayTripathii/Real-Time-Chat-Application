import { Link } from 'react-router-dom';
import { projects } from '../../data/siteData';
import './ProjectsSection.css';

export default function ProjectsSection() {
  return (
    <section className="section ps">
      <div className="container">
        <div className="sec-head">
          <span className="eyebrow">On the ground</span>
          <h2>Our Impact Projects</h2>
          <p>Transforming lives on the ground through meaningful projects that inspire hope, dignity, and long-term impact.</p>
        </div>
        <div className="grid ps-grid">
          {projects.map((p) => (
            <article key={p.slug} className="card ps-card">
              <Link to={`/projects/${p.slug}`} className="ps-img"><img src={p.img} alt={p.title} loading="lazy" /></Link>
              <div className="ps-body">
                <h3><Link to={`/projects/${p.slug}`}>{p.title}</Link></h3>
                <p>{p.text}</p>
                {p.stats.length > 0 && <ul>{p.stats.map((s) => <li key={s}>{s}</li>)}</ul>}
                <Link to={`/projects/${p.slug}`} className="ps-link">View project →</Link>
              </div>
            </article>
          ))}
        </div>
        <div className="center mt"><Link to="/projects" className="btn">Show all projects</Link></div>
      </div>
    </section>
  );
}
