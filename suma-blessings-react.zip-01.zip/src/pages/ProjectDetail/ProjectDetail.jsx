import { useParams, Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import { projects, titleCase } from '../../data/siteData';
import './ProjectDetail.css';

export default function ProjectDetail() {
  const { slug } = useParams();
  const p = projects.find((x) => x.slug === slug);
  const title = p ? p.title : titleCase(slug);
  return (
    <>
      <PageBanner title={title} crumbs={[['Projects', '/projects']]} />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            {p && <img className="pd-img" src={p.img} alt={p.title} />}
            <h2>{title}</h2>
            <p>{p ? p.text : 'Part of Suma Blessings Foundation’s on-the-ground programmes for marginalized communities.'}</p>
            {p?.stats.length > 0 && <ul className="ip-list">{p.stats.map((s) => <li key={s}>{s}</li>)}</ul>}
            <p>Suma Blessings Foundation works in education, healthcare, nutrition, skill development and community empowerment across 3 states. Add the full project story, photos and impact numbers here.</p>
          </div>
          <aside className="ip-side">
            <h3>Support this project</h3>
            <p>Your donation is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
