import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import '../Login/Login.css';
import './Register.css';

export default function Register() {
  return (
    <>
      <PageBanner title="Registration" />
      <section className="section alt">
        <div className="container">
          <form className="card au-card reg" onSubmit={(e) => e.preventDefault()}>
            <h2>Create your account</h2>
            <div className="form-grid">
              <div className="field"><label>First name</label><input required /></div>
              <div className="field"><label>Last name</label><input required /></div>
              <div className="field"><label>Email</label><input type="email" required /></div>
              <div className="field"><label>Mobile</label><input type="tel" required /></div>
              <div className="field"><label>Password</label><input type="password" required /></div>
              <div className="field"><label>Confirm password</label><input type="password" required /></div>
            </div>
            <button className="btn">Register</button>
            <p>Already registered? <Link to="/login">Login</Link></p>
          </form>
        </div>
      </section>
    </>
  );
}
