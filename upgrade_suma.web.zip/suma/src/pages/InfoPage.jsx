import { Link, useLocation } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import { infoPages, projects, festivals } from '../data'
import Img from '../components/Img'
import './InfoPage.css'
export default function InfoPage(){
  const { pathname }=useLocation(),p=infoPages[pathname.replace(/\/$/,'')]
  if(!p) return (<><div className="page-hero"><h1>404 – Page not found</h1></div><div className="container center section"><Link to="/" className="btn">Back to Home</Link></div></>)
  return (<><div className="page-hero"><small>{p.group}</small><h1>{p.title}</h1></div>
  <section className="section"><div className="container info">
    <p className="lead big reveal">{p.intro}</p>
    {p.facts&&<div className="grid g3">{p.facts.map(f=><div key={f} className="fact reveal">{f}</div>)}</div>}
    {p.projects&&<div className="grid g3">{projects.map(x=><Link key={x.path} to={x.path} className="card reveal"><div className="img"><Img name={x.img}/></div><div className="body"><h3>{x.name}</h3><p>{x.sub}</p></div></Link>)}</div>}
    {p.festivals&&<div className="grid g4">{festivals.map(f=><Link key={f[2]} to={f[2]} className="fact reveal">{f[0]} – {f[1]}</Link>)}</div>}
    {p.form&&<form className="lf" onSubmit={e=>e.preventDefault()}><input type="email" placeholder="Email" required/><input type="password" placeholder="Password" required/>{p.form==='register'&&<input placeholder="Full name"/>}<button className="btn">{p.title}</button></form>}
    {p.cta&&<Link to="/donate-now" className="btn">Donate Now <ArrowRight size={18}/></Link>}
  </div></section></>)
}
