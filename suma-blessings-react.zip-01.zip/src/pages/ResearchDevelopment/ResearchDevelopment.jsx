import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './ResearchDevelopment.css';

export default function ResearchDevelopment() {
  return (
    <>
      <PageBanner title="Research & Development" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Evidence-based solutions for social change</h2>
            <p>We study community needs and measure the impact of our programmes so that every rupee is used where it matters most.</p>
            <p>Findings guide the design of new projects and partnerships.</p>
            <ul className="ip-list">
              <li>Community needs assessment</li>
              <li>Impact measurement</li>
              <li>Programme innovation</li>
              <li>Knowledge sharing</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
