import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import Reveal from '../../components/Reveal/Reveal';
import './LegalStatus.css';

const docs = [
  ['Licence under section 8 (1) of the Companies Act, 2013', 'https://drive.google.com/file/d/1TwF0JVZbNLS4cQ3liyfiqRBrNxJ13oY7/view?usp=sharing'],
  ['CSR 1 Certificate', 'https://drive.google.com/file/d/1dtHU-QeHGq_5Ow-e8bSdzV6PdDTKM2AO/view?usp=sharing'],
  ['Registration on Darpan Portal of Niti Ayog', 'https://drive.google.com/file/d/13oFjOx1fbymsSN77wri-CUkMBSVg_LKM/view'],
  ['Certificate of Registration Under Section 80G(5)(vi) of the Income Tax Act, 1961', 'https://drive.google.com/file/d/14JeyHytKh4RyUlovq4DIMDuL7iUlHv3b/view'],
  ['Certificate of Registration Under Section 12A(a) of the Income Tax Act, 1961', 'https://drive.google.com/file/d/1OmWbPKUr5iMOuM82BVTifa_zt02-xSzd/view'],
  ['Certificate of Incorporation (COI)', 'https://drive.google.com/file/d/19J6PbeY_glgPU70fjOdeZlfeiD9HpN-k/view?usp=share_link'],
  ['Pancard', 'https://drive.google.com/file/d/1c1UBB0_3311MoFRfWLMeIqxGA2X6Opb8/view?usp=share_link'],
];

export default function LegalStatus() {
  return (
    <>
      <PageBanner title="Our Legal Status" />
      <section className="section">
        <div className="container center">
          <span className="eyebrow">Governance & trust</span>
          <p className="ls-lead">We publish key registrations and compliance documents so supporters, partners, and communities can verify our legal standing and give with confidence.</p>
          <ul className="ls-pills"><li>Registered entity</li><li>Statutory compliance</li><li>Donor transparency</li></ul>
          <ul className="ls-points"><li>Valid NGO registrations & certificates</li><li>Tax exemptions (12A / 80G) where applicable</li><li>Public filings & updates as required</li></ul>
        </div>
      </section>
      <section className="section alt">
        <div className="container">
          <div className="sec-head"><h2>Documents & registrations</h2><p>Official registrations, exemptions, and public disclosures that support transparency and donor confidence.</p></div>
          <div className="grid ls-grid">
            {docs.map(([t, u]) => (
              <Reveal key={t}><article className="card ls-card">
                <span className="ls-ico">📄</span>
                <h3>{t}</h3>
                <small>PDF or image · opens in a new tab</small>
                <a className="btn sm" href={u} target="_blank" rel="noreferrer">View document</a>
              </article></Reveal>
            ))}
          </div>
        </div>
      </section>
      <section className="section center">
        <div className="container">
          <h2>Need a specific certificate or filing?</h2>
          <p className="ls-lead">For partnership due diligence, institutional grants, or media verification, contact us and we will guide you to the right document or signatory.</p>
          <Link to="/contact" className="btn">Contact our team</Link>
        </div>
      </section>
    </>
  );
}
