import PageBanner from '../../components/PageBanner/PageBanner';
import './VideoGallery.css';

export default function VideoGallery() {
  return (
    <>
      <PageBanner title="Video Gallery" />
      <section className="section">
        <div className="container vg-wrap">
          <h2>Watch our work on the ground</h2>
          <p>Videos of our programmes, events and impact stories are published on our YouTube channel.</p>
          <a className="btn" href="https://www.youtube.com/@sumablessings" target="_blank" rel="noreferrer">Visit YouTube Channel</a>
        </div>
      </section>
    </>
  );
}
