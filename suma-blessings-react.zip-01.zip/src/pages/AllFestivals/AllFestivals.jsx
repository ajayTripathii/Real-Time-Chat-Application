import PageBanner from '../../components/PageBanner/PageBanner';
import FestivalsSection from '../../components/FestivalsSection/FestivalsSection';
import './AllFestivals.css';

export default function AllFestivals() {
  return (<><PageBanner title="All Festivals" /><FestivalsSection all /></>);
}
