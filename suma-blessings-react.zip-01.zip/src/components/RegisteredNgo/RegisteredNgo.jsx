import { Link } from 'react-router-dom';
import { ngoPrograms } from '../../data/siteData';
import './RegisteredNgo.css';

export default function RegisteredNgo() {
  return (
    <section className="section rn">
      <div className="container">
        <div className="rn-top">
          <div>
            <span className="eyebrow">Registered NGO</span>
            <h2>12A & 80G Certified non-profit charity organization</h2>
            <p>Donate us for a good cause and claim 50% tax exemption under section 80G of income tax act.</p>
            <ul className="rn-badges"><li>12A registered</li><li>80G tax benefit</li><li>CSR ready</li></ul>
          </div>
          <div className="rn-grid">
            {ngoPrograms.map(([l, t]) => (
              <Link key={l} to={t} className="rn-card"><h4>{l}</h4><span>Learn more →</span></Link>
            ))}
          </div>
        </div>
        <div className="rn-sdg center">
          <h5>We are committing to</h5>
          <h2>Sustainable Development Goals</h2>
          <img src="https://www.sumablessings.org/assets/images/frontend/sdg/686a7e5ed43bc1751809630.png" alt="Sustainable Development Goals" loading="lazy" />
        </div>
      </div>
    </section>
  );
}
