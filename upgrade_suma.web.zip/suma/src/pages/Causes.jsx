import { useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import Img from '../components/Img'
import { appeals, categories } from '../data'
import './Causes.css'
export default function Causes(){
  const [sp,setSp]=useSearchParams(),cat=sp.get('category')||'All'
  const list=cat==='All'?appeals:appeals.filter((_,i)=>i%categories.length===categories.indexOf(cat)%appeals.length)
  return (<><div className="page-hero"><small>Campaigns</small><h1>Support a Cause</h1></div>
  <section className="section"><div className="container"><div className="pills">{['All',...categories].map(c=><button key={c} className={c===cat?'on':''} onClick={()=>setSp(c==='All'?{}:{category:c})}>{c}</button>)}</div>
    <div className="grid g4">{list.map(a=><Link key={a.path} to={a.path} className="card reveal in"><div className="img"><Img name={a.img}/></div><div className="body"><h3>{a.title}</h3><div className="bar"><i style={{width:Math.max(a.pct,1)+'%'}}/></div><small>{a.pct}% • Raised {a.raised} • Goal {a.goal}</small></div></Link>)}</div></div></section></>)
}
