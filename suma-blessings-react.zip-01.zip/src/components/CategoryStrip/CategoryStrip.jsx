import { Link } from 'react-router-dom';
import { categories } from '../../data/siteData';
import './CategoryStrip.css';

export default function CategoryStrip() {
  return (
    <section className="cs">
      <div className="container cs-grid">
        {categories.map((c) => (
          <Link key={c.name} to={`/cause?category=${encodeURIComponent(c.name)}`} className="cs-item">
            <span className="cs-img"><img src={c.img} alt={c.name} loading="lazy" /></span>
            <h4>{c.name}</h4>
          </Link>
        ))}
      </div>
    </section>
  );
}
