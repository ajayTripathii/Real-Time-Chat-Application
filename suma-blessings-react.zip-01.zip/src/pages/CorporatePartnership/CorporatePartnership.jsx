import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './CorporatePartnership.css';

export default function CorporatePartnership() {
  return (
    <>
      <PageBanner title="Corporate Partnership" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Make your CSR count</h2>
            <p>Explore curated CSR programs that match your company's goals while uplifting the underprivileged.</p>
            <p>We offer 80G tax benefit, CSR-ready programmes and transparent reporting.</p>
            <ul className="ip-list">
              <li>Employee volunteering</li>
              <li>Project sponsorship</li>
              <li>CSR-compliant reporting</li>
              <li>Long-term partnerships</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
