import { useState } from 'react';
import { useDonation } from '../../context/DonationContext';
import { inr } from '../../data/siteData';
import './DonateModal.css';

export default function DonateModal() {
  const { open, setOpen, items, remove, total } = useDonation();
  const [msg, setMsg] = useState('');
  if (!open) return null;
  const proceed = () => setMsg(items.length ? 'Payment gateway can be connected here (Razorpay / PayU / Cashfree).' : 'Please select an amount to donate first.');
  return (
    <div className="dm-back" onClick={() => setOpen(false)}>
      <div className="dm" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
        <button className="dm-x" onClick={() => setOpen(false)} aria-label="Close">✕</button>
        <h3>Your selected donations</h3>
        <span className="dm-badge">80G eligible</span>
        <div className="dm-scroll">
          <table>
            <thead><tr><th>Particular</th><th>Amount</th><th>Remove</th></tr></thead>
            <tbody>
              {items.map((i) => (
                <tr key={i.id}><td>{i.title}</td><td>{inr(i.amount)}</td><td><button onClick={() => remove(i.id)}>✕</button></td></tr>
              ))}
              <tr className="tot"><td>Total</td><td colSpan="2">{inr(total)}</td></tr>
            </tbody>
          </table>
        </div>
        <p className="dm-note">Review your selections before proceeding. Donations may be eligible for tax benefit under Section 80G.</p>
        {msg && <p className="dm-msg">{msg}</p>}
        <button className="btn" onClick={proceed}>Proceed to Donate</button>
      </div>
    </div>
  );
}
