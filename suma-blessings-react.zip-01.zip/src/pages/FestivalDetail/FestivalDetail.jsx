import { useState } from 'react';
import { useParams } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import { festivals, occasions, inr, titleCase } from '../../data/siteData';
import { useDonation } from '../../context/DonationContext';
import './FestivalDetail.css';

export default function FestivalDetail({ slug: slugProp }) {
  const params = useParams();
  const slug = slugProp || params.slug;
  const f = festivals.find((x) => x.slug === slug);
  const o = occasions.find((x) => x.slug === slug);
  const name = f?.name || o?.name || titleCase(slug);
  const { add } = useDonation();
  const [amt, setAmt] = useState(1100);
  return (
    <>
      <PageBanner title={name} />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            {o && <img className="fd-img" src={o.img} alt={o.name} />}
            <h2>Celebrate {name} by giving</h2>
            {f && <p className="fd-date">📅 {f.day} {f.mon} {f.year}</p>}
            <p>Make this occasion more meaningful by sharing joy with children, women and families supported by Suma Blessings Foundation. Your gift can provide meals, school supplies, healthcare and more.</p>
            <ul className="ip-list"><li>80G tax benefit on every donation</li><li>Transparent reporting of how your gift is used</li><li>Option to donate in honor of a loved one</li></ul>
          </div>
          <aside className="ip-side">
            <h3>Donate on {name}</h3>
            <div className="field"><label>Amount (₹)</label><input type="number" min="1" value={amt} onChange={(e) => setAmt(e.target.value)} /></div>
            <p className="fd-note">Selected: {inr(amt || 0)}</p>
            <button className="btn" onClick={() => amt > 0 && add({ id: slug, title: name, amount: amt })}>Donate Now</button>
          </aside>
        </div>
      </section>
    </>
  );
}
