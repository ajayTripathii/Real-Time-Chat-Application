import { useParams, Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import { events, titleCase } from '../../data/siteData';
import './EventDetail.css';

export default function EventDetail() {
  const { slug } = useParams();
  const e = events.find((x) => x.slug === slug);
  const title = e ? e.title : titleCase(slug);
  return (
    <>
      <PageBanner title={title} crumbs={[['Events', '/events']]} />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>{title}</h2>
            <p>{e ? e.text : 'Details of this event will be updated shortly.'}</p>
            <p>Suma Blessings Foundation regularly organises drives, workshops and celebrations with the communities it serves. Join us as a volunteer or supporter to be part of the next one.</p>
          </div>
          <aside className="ip-side">
            <h3>Event details</h3>
            {e && <ul className="ed-meta"><li>📅 {e.day} {e.mon}</li>{e.time && <li>🕒 {e.time}</li>}{e.venue && <li>📍 {e.venue}</li>}</ul>}
            <Link to="/volunteering-opportunities" className="btn">Volunteer with us</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
