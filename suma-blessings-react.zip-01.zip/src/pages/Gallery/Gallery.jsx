import PageBanner from '../../components/PageBanner/PageBanner';
import { categories, blogs, projects, causes } from '../../data/siteData';
import './Gallery.css';

const imgs = [...categories.map((c) => [c.img, c.name]), ...projects.map((p) => [p.img, p.title]), ...causes.map((c) => [c.img, c.category]), ...blogs.slice(0, 8).map((b) => [b.img, 'Event'])];

export default function Gallery() {
  return (
    <>
      <PageBanner title="Image Gallery" />
      <section className="section"><div className="container gl-grid">
        {imgs.map(([src, alt], i) => (<figure key={i}><img src={src} alt={alt} loading="lazy" /><figcaption>{alt}</figcaption></figure>))}
      </div></section>
    </>
  );
}
