import { Link } from 'react-router-dom';
import { causes } from '../../data/siteData';
import CauseCard from './CauseCard';
import './AppealsSection.css';

export default function AppealsSection() {
  return (
    <section className="section alt">
      <div className="container">
        <div className="sec-head">
          <h2>Recent Appeals - Pick a cause close to your heart and donate now</h2>
          <p>Stand up for what matters! Join us in supporting our campaigns and make a difference today. Every donation counts, so let’s turn compassion into action.</p>
          <ul className="ap-badges"><li>Verified causes</li><li>Tax benefit eligible</li><li>Transparent progress</li></ul>
        </div>
        <div className="grid ap-grid">{causes.map((c) => <CauseCard key={c.slug} c={c} />)}</div>
        <div className="center mt"><Link to="/cause" className="btn">Find all causes</Link></div>
      </div>
    </section>
  );
}
