import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './AwarenessProgram.css';

export default function AwarenessProgram() {
  return (
    <>
      <PageBanner title="Awareness Program" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Knowledge that changes lives</h2>
            <p>Our awareness programmes bring experts to communities on topics such as breast cancer, menstrual hygiene, nutrition and digital safety.</p>
            <p>Informed communities make better choices for their health and future.</p>
            <ul className="ip-list">
              <li>Health awareness sessions</li>
              <li>Women's health workshops</li>
              <li>Child rights and safety</li>
              <li>Digital and AI learning</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
