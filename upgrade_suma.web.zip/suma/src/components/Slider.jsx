import { useEffect, useState, useCallback } from 'react'
import { Link } from 'react-router-dom'
import { ChevronLeft, ChevronRight, ArrowRight } from 'lucide-react'
import Img from './Img'
import './Slider.css'
export default function Slider({ slides }){
  const [i,setI]=useState(0),[pause,setPause]=useState(false)
  const go=useCallback(n=>setI((n+slides.length)%slides.length),[slides.length])
  useEffect(()=>{ if(pause) return; const t=setInterval(()=>setI(x=>(x+1)%slides.length),5500); return()=>clearInterval(t)},[pause,slides.length])
  return (
    <section className="slider" onMouseEnter={()=>setPause(true)} onMouseLeave={()=>setPause(false)}>
      {slides.map((s,n)=>(
        <div key={n} className={'slide'+(n===i?' active':'')}>
          <div className="bg"><Img name={s.img}/></div><div className="shade"/>
          <div className="container txt"><span className="tag">{s.tag}</span><h2>{s.title}</h2>
            <Link to={s.link} className="btn">Read More <ArrowRight size={18}/></Link></div>
        </div>))}
      <button className="nav prev" onClick={()=>go(i-1)} aria-label="Previous"><ChevronLeft/></button>
      <button className="nav next" onClick={()=>go(i+1)} aria-label="Next"><ChevronRight/></button>
      <div className="dots">{slides.map((_,n)=><button key={n} className={n===i?'on':''} onClick={()=>go(n)} aria-label={'Slide '+(n+1)}/>)}</div>
      <div className="prog" key={i+String(pause)} style={{animationPlayState:pause?'paused':'running'}}/>
    </section>)
}
