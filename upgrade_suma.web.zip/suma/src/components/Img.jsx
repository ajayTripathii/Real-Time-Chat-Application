import { useState } from 'react'
import { Heart } from 'lucide-react'
import { IMG } from '../data'
export default function Img({ name, alt='' }){
  const [bad,setBad]=useState(false)
  const h=[...(name||'x')].reduce((a,c)=>a+c.charCodeAt(0),0)%360
  if(bad||!name) return <div className="ph" style={{background:`linear-gradient(135deg,hsl(${h},70%,50%),hsl(${(h+50)%360},70%,38%))`}}><Heart size={34}/></div>
  return <img src={IMG+name} alt={alt} loading="lazy" onError={()=>setBad(true)}/>
}
