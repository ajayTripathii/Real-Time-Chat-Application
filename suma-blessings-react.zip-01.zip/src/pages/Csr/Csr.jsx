import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './Csr.css';

export default function Csr() {
  return (
    <>
      <PageBanner title="CSR Programmes" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Accelerate your CSR goals</h2>
            <p>Partner with Suma Blessings Foundation to deliver measurable social impact in education, healthcare, nutrition, skills and environment.</p>
            <p>Our team will help you shortlist projects aligned with your CSR policy.</p>
            <ul className="ip-list">
              <li>80G tax benefit</li>
              <li>CSR-ready programmes</li>
              <li>Transparent reporting</li>
              <li>On-ground project visits</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
