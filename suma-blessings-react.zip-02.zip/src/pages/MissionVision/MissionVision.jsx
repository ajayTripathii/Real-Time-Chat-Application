import PageBanner from '../../components/PageBanner/PageBanner';
import Reveal from '../../components/Reveal/Reveal';
import './MissionVision.css';

export default function MissionVision() {
  return (
    <>
      <PageBanner title="Our Vision & Mission" />
      <section className="section">
        <div className="container center">
          <span className="eyebrow">Purpose</span>
          <p className="mv-lead">Our mission and vision express why we exist, what we uphold, and the future we strive to build with donors, partners, and communities.</p>
          <ul className="mv-pills"><li>Mission clarity</li><li>Long-term vision</li><li>Values in action</li></ul>
        </div>
      </section>
      <section className="section alt">
        <Reveal><div className="container mv-row">
          <img src="https://www.sumablessings.org/assets/images/category/63ce73ef358a31674474479.jpg" alt="Our Mission" />
          <div><h2>Our Mission</h2>
            <ul className="ip-list">
              <li>Suma Blessings Foundation empowers underprivileged individuals through education, healthcare, and livelihood programmes to combat poverty and improve lives.</li>
              <li>The foundation aims to create a world where everyone has access to education, nutrition, and freedom from diseases.</li>
            </ul>
          </div>
        </div></Reveal>
      </section>
      <section className="section">
        <Reveal><div className="container mv-row rev">
          <div><h2>Our Vision</h2><p>A just and compassionate society with empowered communities with sustainable access to education, health, nutrition, and digital opportunity and clean energy.</p></div>
          <img src="https://www.sumablessings.org/assets/images/category/63ce74489755e1674474568.jpg" alt="Our Vision" />
        </div></Reveal>
      </section>
    </>
  );
}
