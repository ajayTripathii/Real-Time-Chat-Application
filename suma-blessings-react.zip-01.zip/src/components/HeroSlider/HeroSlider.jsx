import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { heroSlides } from '../../data/siteData';
import './HeroSlider.css';

export default function HeroSlider() {
  const [i, setI] = useState(0);
  const n = heroSlides.length;
  useEffect(() => {
    const t = setInterval(() => setI((p) => (p + 1) % n), 5500);
    return () => clearInterval(t);
  }, [n]);
  return (
    <section className="hs">
      {heroSlides.map((s, k) => (
        <div key={k} className={`hs-slide ${k === i ? 'on' : ''}`} style={{ background: s.bg }}>
          <div className="container hs-in">
            <span className="hs-tag">{s.tag}</span>
            <h2>{s.title}</h2>
            <Link to={s.to} className="btn">Read More</Link>
          </div>
        </div>
      ))}
      <button className="hs-arrow l" onClick={() => setI((i - 1 + n) % n)} aria-label="Previous">‹</button>
      <button className="hs-arrow r" onClick={() => setI((i + 1) % n)} aria-label="Next">›</button>
      <div className="hs-dots">{heroSlides.map((_, k) => <button key={k} className={k === i ? 'on' : ''} onClick={() => setI(k)} aria-label={`Slide ${k + 1}`} />)}</div>
    </section>
  );
}
