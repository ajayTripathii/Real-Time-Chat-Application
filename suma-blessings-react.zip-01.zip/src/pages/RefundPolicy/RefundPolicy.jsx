import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './RefundPolicy.css';

export default function RefundPolicy() {
  return (
    <>
      <PageBanner title="Refund Policy" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Our policy on donation refunds</h2>
            <p>Donations are generally non-refundable. In case of a failed or duplicate transaction, please contact us with transaction details.</p>
            <p>Add your full refund policy text here.</p>
            <ul className="ip-list">
              <li>Failed transactions</li>
              <li>Duplicate payments</li>
              <li>How to request a refund</li>
              <li>Processing time</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
