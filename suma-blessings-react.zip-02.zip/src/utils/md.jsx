export const md = (s) => s.split('**').map((p, i) => (i % 2 ? <b key={i}>{p}</b> : p));
