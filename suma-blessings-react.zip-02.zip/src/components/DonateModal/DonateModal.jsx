import { useState } from 'react';
import { useDonation } from '../../context/DonationContext';
import { useToast } from '../../context/ToastContext';
import { inr } from '../../data/siteData';
import './DonateModal.css';

export default function DonateModal() {
  const { open, setOpen, items, remove, clear, total } = useDonation();
  const toast = useToast();
  const [step, setStep] = useState('cart');
  const [ref, setRef] = useState('');
  if (!open) return null;

  const close = () => { setOpen(false); if (step === 'done') { clear(); } setTimeout(() => setStep('cart'), 200); };
  const next = () => {
    if (!items.length) { toast('Please select an amount to donate first.', 'error'); return; }
    setStep('form');
  };
  const submit = (e) => {
    e.preventDefault();
    setRef('SBF-' + Math.random().toString(36).slice(2, 8).toUpperCase());
    setStep('done');
    toast('Details received. Thank you for your generosity!');
  };

  return (
    <div className="dm-back" onClick={close}>
      <div className="dm" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
        <button className="dm-x" onClick={close} aria-label="Close">✕</button>
        {step === 'cart' && (
          <>
            <h3>Your selected donations</h3>
            <span className="dm-badge">80G eligible</span>
            <div className="dm-scroll">
              <table>
                <thead><tr><th>Particular</th><th>Amount</th><th>Remove</th></tr></thead>
                <tbody>
                  {items.map((i) => (<tr key={i.id}><td>{i.title}</td><td>{inr(i.amount)}</td><td><button onClick={() => { remove(i.id); toast('Removed from your donations', 'error'); }} aria-label="Remove">✕</button></td></tr>))}
                  <tr className="tot"><td>Total</td><td colSpan="2">{inr(total)}</td></tr>
                </tbody>
              </table>
            </div>
            {!items.length && <p className="dm-empty">No donation selected yet.</p>}
            <p className="dm-note">Review your selections before proceeding. Donations may be eligible for tax benefit under Section 80G.</p>
            <button className="btn" onClick={next}>Proceed to Donate</button>
          </>
        )}
        {step === 'form' && (
          <form onSubmit={submit}>
            <h3>Donor details</h3>
            <p className="dm-note">Total payable: <b>{inr(total)}</b> (80G receipt will be sent to your email)</p>
            <div className="form-grid">
              <div className="field full"><label>Full name</label><input required /></div>
              <div className="field"><label>Email</label><input type="email" required /></div>
              <div className="field"><label>Mobile</label><input type="tel" pattern="[0-9+ ]{10,14}" required /></div>
              <div className="field full"><label>PAN (for 80G receipt)</label><input maxLength="10" placeholder="ABCDE1234F" style={{ textTransform: 'uppercase' }} /></div>
            </div>
            <div className="dm-actions"><button type="button" className="btn outline" onClick={() => setStep('cart')}>Back</button><button className="btn">Confirm donation</button></div>
          </form>
        )}
        {step === 'done' && (
          <div className="dm-done">
            <div className="dm-tick">✓</div>
            <h3>Thank you for your kindness!</h3>
            <p>Your donation of <b>{inr(total)}</b> is noted. Reference: <b>{ref}</b></p>
            <p className="dm-note">Connect your payment gateway (Razorpay / PayU / Cashfree) here to complete real transactions.</p>
            <button className="btn" onClick={close}>Close</button>
          </div>
        )}
      </div>
    </div>
  );
}
