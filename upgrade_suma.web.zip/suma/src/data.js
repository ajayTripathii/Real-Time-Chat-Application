// All editable content lives here. Replace text / image names with your own.
export const IMG = '/images/'
export const nav = [
 { label:'About Us', items:[['About Suma Blessings','/about'],['Mission & Vision','/mission-vision'],['Our Journey','/our-journey'],['Legal Status','/our-legal-status'],['Board Members','/founding-members'],['Management Team','/team']] },
 { label:'What We do', items:[['Education','/education'],['Food & Nutrition','/food-nutrition'],['Healthcare','/healthcare'],['Women Empowerment','/women-empowerment'],['Environment','/environment'],['Awareness Program','/awareness-program'],['Research & Development','/research-development']] },
 { label:'Projects', items:[['Child Education','/projects/child-education'],['Skill Development','/projects/skill-development'],['Food & Nutrition','/projects/health-and-nutrition'],['Healthcare','/projects/healthcare'],['Environmental Sustainability','/projects/environment'],['Women Empowerment','/projects/women-empowerment']] },
 { label:'Get Involved', items:[['Corporate Partnership','/corporate-partnership'],['School Partnerships','/school-partnerships'],['Volunteers','/volunteering-opportunities'],['Internships','/become-an-intern'],['Membership','/become-a-member'],['Work with Us','/career']] },
 { label:'Media', items:[['Image Gallery','/gallery'],['Video Gallery','/video'],['Workshops & Events','/events'],['Print / Online Media','/print-online-media'],['Electronic Media','/electronic-media']] },
 { label:'Resource', items:[['The Suma Blog','/news'],['Newsletter','/newsletter'],['Annual Reports','/annual-reports'],['Stories of Change','/stories-of-change']] },
]
export const slides = [
 { tag:'Disability Inclusion', title:'Empowering Persons with Disabilities Through Inclusion', link:'/projects/suma-saksham-disability-inclusion', img:'slide1.jpg' },
 { tag:'Empowering Skills, Creating Opportunities', title:'Practical skills, vocational training and livelihoods for underserved communities', link:'/skill-development-program', img:'slide2.jpg' },
 { tag:'Bringing Healthcare Closer', title:'Healthcare support, awareness and access to essential medical services', link:'/healthcare', img:'slide3.jpg' },
 { tag:'500 Families • 1 Mission • Countless Smiles', title:'Join our Diwali Joy Kit Drive', link:'/events/diwali-joy-kit-distribution-2025', img:'slide4.jpg' },
 { tag:'Child Education', title:'A community-based learning centre for children from underprivileged backgrounds', link:'/education', img:'slide5.jpg' },
 { tag:'Women Empowerment', title:'Supporting women in realizing their dreams', link:'/womens-day', img:'slide6.jpg' },
 { tag:'Suma Vidyalaya', title:'Every child deserves a bright future', link:'/projects/child-education/suma-vidyalaya', img:'slide7.jpg' },
]
export const categories = ['Skill Development','Environment','Food & Nutrition','Healthcare','Women Empowerment','Education','Children']
export const whatWeDo = [['Child Education','/education'],['Healthcare','/healthcare'],['Food and Nutrition','/food-nutrition'],['Women Empowerment','/women-empowerment'],['Skill Development','/skill-development-program'],['Save the Environment','/environment'],['Awareness Program','/awareness-program'],['Research and Development','/research-development']]
export const stats = [['3','States'],['1 Million+','Meals served'],['15+','Education Centers and Schools'],['5000+','Students']]
export const projects = [
 { name:'Suma Saksham', sub:'Empowering Abilities, Creating Equal Opportunities', path:'/projects/suma-saksham-disability-inclusion', img:'p1.jpg' },
 { name:'Suma Care', sub:'General Duty Assistant (GDA) Training Initiative', path:'/projects/general-duty-assistant-training', img:'p2.jpg' },
 { name:'Silai Se Samriddhi', sub:'Hunar Se Samman, Silai Se Samriddhi', path:'/projects/silai-se-samriddhi', img:'p3.jpg', facts:['200+ women enrolled','10+ Self-help groups','30+ Women trained per batch'] },
 { name:'Suma Aarogya Raah', sub:'Providing access to healthcare for all.', path:'/projects/suma-aarogya-raah', img:'p4.jpg', facts:['20+ Health camps conducted','3000+ Beneficiaries','500+ Sanitary kits distributed'] },
 { name:'Suma Spoon of Love', sub:"More Than Food. It's Love Served on a Plate.", path:'/projects/suma-spoon-of-love', img:'p5.jpg', facts:['1M+ Food Distributed','30+ Communities Reached','1800+ Ration kits delivered'] },
]
export const appeals = [
 { title:'Sanitary Dignity Kits – Empowering Adolescent Girls', path:'/cause/sanitary-dignity-kits', pct:53.5, raised:'₹58,853', goal:'₹110,000', img:'a1.jpg' },
 { title:'Medical Financial Assistance For Souray Raikwar', path:'/cause/request-for-medical-financial-assistance-for-souray-raikwar', pct:66.6, raised:'₹380,815', goal:'₹571,765', img:'a2.jpg' },
 { title:"Donate Desktops for Suma Vidyalaya's Children", path:'/cause/basic-computer-training-for-poor-children', pct:11, raised:'₹38,500', goal:'₹350,000', img:'a3.jpg' },
 { title:'Sponsor a Meal – Nourish a Tribal Community', path:'/cause/sponsor-meals-for-a-poor-tribal-child', pct:0.01, raised:'5 Meal(s)', goal:'36,000 Meal(s)', img:'a4.jpg' },
]
export const involve = [
 { t:'Membership', p:'/become-a-member', d:'Open to everyone. Contribute a monthly donation, become a member and help sponsor education, food and healthcare for children.', img:'g1.jpg' },
 { t:'Internship', p:'/become-an-intern', d:'For anyone who can commit a minimum duration, on-site or online. Interns receive a certificate on completion.', img:'g2.jpg' },
 { t:'Volunteership', p:'/volunteering-opportunities', d:'Volunteer in person or online, as per your availability. No fixed commitment is required.', img:'g3.jpg' },
]
export const festivals = [['25 Dec','Merry Christmas','/merry-christmas'],['01 Jan','Happy New Year','/newyear'],['13 Jan','Lohri','/lohri'],['14 Jan','Makar Sankranti','/makar-sankranti'],['15 Jan','Pongal','/pongal'],['23 Jan','Basant Panchami','/basant-panchami'],['15 Feb','Mahashivratri','/mahashivratri'],['04 Mar','Happy Holi','/holi'],['08 Mar',"Women's Day",'/womens-day'],['19 Mar','Chaitra Navratri','/chaitra-navratri-charity'],['19 Mar','Gudi Padwa','/gudi-padwa'],['15 Aug','Independence Day','/independence-day'],['28 Aug','Raksha Bandhan','/raksha-bandhan'],['04 Sep','Janmashtami','/janmashtami'],['14 Sep','Ganesh Chaturthi','/donate-on-this-ganesh-chaturthi'],['26 Sep','Pitru Paksha Donation','/pitrupaksha-donation'],['02 Oct','Daan Utsav','/daan-utsav'],['11 Oct','Navratri Donation','/navratri-donation'],['25 Oct','Sharad Purnima','/sharad-purnima'],['06 Nov','Diwali Celebration','/diwali-donation'],['06 Nov','Dhanteras','/dhanteras'],['13 Nov','Chhath Puja','/chhath-puja'],['14 Nov',"Children's Day",'/children-day']]
export const occasions = [['Birthday Donation','/birthday','o1.jpg'],['Anniversary','/anniversary-donation','o2.jpg'],["Mother's Day",'/mothers-day','o3.jpg'],['Death Anniversary','/death-anniversary','o4.jpg'],["Valentine's day",'/valentine-day','o5.jpg'],['Donate in Honor','/donate-in-honor','o6.jpg']]
export const events = [
 { d:'19 Nov', t:'Menstrual Health & Hygiene Workshop & Sanitary Pads Distribution Camp', loc:'Delhi Cant, New Delhi', p:'/events/menstrual-health-hygiene-camp-in-delhi-cantt', img:'e1.jpg' },
 { d:'14 Nov', t:'AI Learning Session 2026 – Empowering Young Minds', loc:'Baprola Vihar, Najafgarh, New Delhi', p:'/events/ai-learning-session-2026', img:'e2.jpg' },
 { d:'07 Nov', t:'Diwali Celebration at Suma Vidyalaya', loc:'Baprola Vihar, New Delhi', p:'/events/diwali-celebration-at-suma-vidyalaya-spreading-happiness-sharing-love', img:'e3.jpg' },
 { d:'30 Sep', t:'Breast Cancer Awareness & Research Session', loc:'Baprola Road, Najafgarh, New Delhi', p:'/events/breast-cancer-awareness-research-session', img:'e4.jpg' },
 { d:'15 Aug', t:'80th Independence Day with Children at Suma Vidyalaya', loc:'Uttam Nagar, New Delhi', p:'/events/80th-independence-day-celebrated-with-children-at-suma-vidyalaya', img:'e5.jpg' },
]
export const news = [
 ['Celebrate Your Birthday with Underprivileged Children','Oct 14, 2026','/news/celebrate-your-birthday-with-underprivileged-children'],
 ['Raksha Bandhan 2026: Celebrating the Bond of Love','Aug 17, 2026','/news/raksha-bandhan-2026'],
 ['Friendship Day 2026: Friendship Through Kindness','Jul 30, 2026','/news/friendship-day-2026'],
 ['World Lung Cancer Day 2026: Every Breath Matters','Jul 30, 2026','/news/world-lung-cancer-day-2026'],
 ['Navratri Types: A Complete Guide to the 4 Navratris','Mar 19, 2026','/news/navratri-types-a-complete-guide-to-the-4-navratris-in-india'],
 ['Importance of Daan on Basant Panchami','Jan 13, 2026','/news/importance-of-daan-on-basant-panchami-donate-for-saraswati-puja'],
 ['How Daan Utsav 2025 Inspires Collective Giving','Sep 23, 2025','/news/how-daan-utsav-2025'],
 ['Suma Blessings at India CSR & Sustainability Conclave 2025','Aug 6, 2025','/news/empowering-sustainability-through-participation'],
].map(([t,d,p],i)=>({t,d,p,img:`n${i+1}.jpg`}))
export const contact = { phone:'+91 9971759656', email:'info@sumablessings.org', addr:'House No. 462, Baprola Road, Najafgarh, New Delhi – 110043' }
export const social = [['facebook','https://www.facebook.com/sumablessings'],['instagram','https://www.instagram.com/sumablessings'],['twitter','https://www.twitter.com/sumablessings'],['linkedin','https://www.linkedin.com/company/sumablessings/'],['youtube','https://www.youtube.com/@sumablessings']]
// Generic info pages (everything not given a dedicated page)
const intro = (l)=>`${l} is part of Suma Blessings Foundation's work for marginalized communities. Replace this paragraph in src/data.js with your own page content.`
const dedicated = ['/about','/events','/news']
const info = {}
nav.forEach(g=>g.items.forEach(([l,p])=>{ if(!dedicated.includes(p)) info[p]={title:l,group:g.label,intro:intro(l)} }))
festivals.forEach(([d,l,p])=>info[p]={title:l,group:'Festive Donation',intro:intro(l),cta:true})
occasions.forEach(([l,p])=>info[p]={title:l,group:'Special Occasion',intro:intro(l),cta:true})
projects.forEach(x=>info[x.path]={title:x.name,group:'Projects',intro:x.sub,facts:x.facts,cta:true})
events.forEach(x=>info[x.p]={title:x.t,group:'Events',intro:`${x.d} • ${x.loc}`})
news.forEach(x=>info[x.p]={title:x.t,group:'News & Blogs',intro:`Published ${x.d} by Team.`})
appeals.forEach(x=>info[x.path]={title:x.title,group:'Campaign',intro:`Raised ${x.raised} of ${x.goal}.`,cta:true})
Object.assign(info,{'/mission-vision':{title:'Mission & Vision',group:'About Us',intro:intro('Mission & Vision')},'/csr':{title:'CSR Partnership',group:'Partnership',intro:intro('CSR'),cta:true},'/all-festivals':{title:'All Festivals',group:'Festive Donation',intro:'Donate on any festive occasion.',festivals:true},'/privacy-policy':{title:'Privacy & Policy',group:'Legal',intro:intro('Privacy Policy')},'/terms-and-condition':{title:'Terms & Condition',group:'Legal',intro:intro('Terms')},'/refund-policy':{title:'Refund Policy',group:'Legal',intro:intro('Refund Policy')},'/login':{title:'Login',group:'Account',intro:'Sign in to your account.',form:'login'},'/register':{title:'Registration',group:'Account',intro:'Create your donor account.',form:'register'},'/projects':{title:'Our Impact Projects',group:'Projects',intro:'Transforming lives on the ground.',projects:true}})
export const infoPages = info
