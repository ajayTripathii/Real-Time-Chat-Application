import { createContext, useCallback, useContext, useState } from 'react';

const T = createContext(() => {});
export const useToast = () => useContext(T);

export function ToastProvider({ children }) {
  const [list, setList] = useState([]);
  const toast = useCallback((msg, type = 'success') => {
    const id = Date.now() + Math.random();
    setList((l) => [...l, { id, msg, type }]);
    setTimeout(() => setList((l) => l.filter((t) => t.id !== id)), 3800);
  }, []);
  return (
    <T.Provider value={toast}>
      {children}
      <div className="toasts" aria-live="polite">
        {list.map((t) => (<div key={t.id} className={`toast ${t.type}`}><span>{t.type === 'success' ? '✓' : '!'}</span>{t.msg}</div>))}
      </div>
    </T.Provider>
  );
}
