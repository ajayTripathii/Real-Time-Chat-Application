import { Link } from 'react-router-dom';

export default function BlogCard({ b }) {
  return (
    <article className="card bg-card">
      <Link to={`/news/${b.slug}`} className="bg-img"><img src={b.img} alt={b.title} loading="lazy" /></Link>
      <div className="bg-body">
        <ul><li>by Team</li><li>{b.date}</li></ul>
        <h3><Link to={`/news/${b.slug}`}>{b.title.length > 75 ? b.title.slice(0, 72) + '...' : b.title}</Link></h3>
        <Link to={`/news/${b.slug}`} className="bg-more">Read article →</Link>
      </div>
    </article>
  );
}
