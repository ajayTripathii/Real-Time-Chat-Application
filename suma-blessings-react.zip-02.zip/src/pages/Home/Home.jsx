import HeroSlider from '../../components/HeroSlider/HeroSlider';
import CategoryStrip from '../../components/CategoryStrip/CategoryStrip';
import RegisteredNgo from '../../components/RegisteredNgo/RegisteredNgo';
import AboutSection from '../../components/AboutSection/AboutSection';
import CsrSection from '../../components/CsrSection/CsrSection';
import ProjectsSection from '../../components/ProjectsSection/ProjectsSection';
import AppealsSection from '../../components/AppealsSection/AppealsSection';
import InvolvedSection from '../../components/InvolvedSection/InvolvedSection';
import FestivalsSection from '../../components/FestivalsSection/FestivalsSection';
import OccasionsSection from '../../components/OccasionsSection/OccasionsSection';
import EventsSection from '../../components/EventsSection/EventsSection';
import BlogSection from '../../components/BlogSection/BlogSection';
import Reveal from '../../components/Reveal/Reveal';
import './Home.css';

export default function Home() {
  return (
    <div className="home">
      <HeroSlider />
      <Reveal><CategoryStrip /></Reveal>
      <Reveal><RegisteredNgo /></Reveal>
      <Reveal><AboutSection /></Reveal>
      <Reveal><CsrSection /></Reveal>
      <Reveal><ProjectsSection /></Reveal>
      <Reveal><AppealsSection /></Reveal>
      <Reveal><InvolvedSection /></Reveal>
      <Reveal><FestivalsSection /></Reveal>
      <Reveal><OccasionsSection /></Reveal>
      <Reveal><EventsSection /></Reveal>
      <Reveal><BlogSection /></Reveal>
    </div>
  );
}
