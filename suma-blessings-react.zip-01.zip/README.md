# Suma Blessings Foundation – React Frontend

```bash
npm install
npm run dev      # http://localhost:5173
npm run build
```

- `src/components/*` – Header, Footer, Home sections, shared widgets (each with its own .jsx + .css)
- `src/pages/*` – every route page (each with its own .jsx + .css)
- `src/data/siteData.js` – all content (menu, projects, causes, festivals, events, blogs). Edit here.
- `src/pages/generatedRoutes.js` – routes for the content/form pages
