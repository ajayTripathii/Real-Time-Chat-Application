import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './Healthcare.css';

export default function Healthcare() {
  return (
    <>
      <PageBanner title="Healthcare" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Bringing healthcare closer to those in need</h2>
            <p>Suma Aarogya Raah provides health camps, awareness sessions and access to essential medical services for underserved communities.</p>
            <p>So far 20+ health camps have reached 3000+ beneficiaries, and 500+ sanitary kits have been distributed.</p>
            <ul className="ip-list">
              <li>Free health camps</li>
              <li>Menstrual health and hygiene workshops</li>
              <li>Medical financial assistance</li>
              <li>Cancer and women's health awareness</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
