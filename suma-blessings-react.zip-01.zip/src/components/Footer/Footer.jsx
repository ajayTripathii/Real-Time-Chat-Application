import { Link } from 'react-router-dom';
import { useState } from 'react';
import { FAVICON, PHONE, EMAIL, festivals, occasions, events, socials } from '../../data/siteData';
import './Footer.css';

const about = [['About Suma Blessings', '/about'], ['Legal Status', '/our-legal-status'], ['Our Journey', '/our-journey'], ['Reach & Presence', '/about']];
const projects = [['Suma Vidyalaya', '/projects/suma-vidyalaya'], ['Silai se Samriddhi', '/projects/silai-se-samriddhi'], ['Suma Aarogya Raah', '/projects/suma-aarogya-raah'], ['Suma Spoon of love', '/projects/suma-spoon-of-love'], ['Suma Shashakt', '/projects/suma-shashakt']];
const involve = [['Corporate Partnership', '/corporate-partnership'], ['School Partnership', '/school-partnerships'], ['Support a Cause', '/cause'], ['Membership', '/become-a-member'], ['Careers', '/career']];
const resources = [['The Suma Blog', '/news'], ['Our events', '/events'], ['Newsletter', '/newsletter'], ['Annual Report', '/annual-reports'], ['Stories of Change', '/stories-of-change']];
const letters = { YouTube: 'YT', LinkedIn: 'in', Twitter: 'X', Instagram: 'IG', Facebook: 'f' };

export default function Footer() {
  const [email, setEmail] = useState('');
  const [done, setDone] = useState(false);
  const fest = festivals.filter((f) => ['raksha-bandhan', 'janmashtami', 'independence-day', 'navratri-donation', 'diwali-donation', 'sharad-purnima', 'chhath-puja', 'children-day', 'merry-christmas', 'makar-sankranti', 'pongal', 'basant-panchami', 'mahashivratri', 'womens-day', 'holi', 'gudi-padwa', 'chaitra-navratri-charity', 'pitrupaksha-donation', 'dhanteras', 'daan-utsav', 'newyear', 'lohri', 'donate-on-this-ganesh-chaturthi'].includes(f.slug));
  return (
    <footer className="ft">
      <div className="ft-strip"><div className="container">Donations are eligible for tax benefit under Section 80G.</div></div>
      <div className="container ft-top">
        <div className="ft-brand">
          <Link to="/" className="ft-logo"><img src={FAVICON} alt="Suma Blessings Foundation" /><span><b>Suma Blessings Foundation</b><em>Everything for happiness</em></span></Link>
          <p>Donations are eligible for tax benefit under Section 80G.</p>
          <div className="ft-counters">
            <div><h4>528</h4><span>Total Donate Members</span></div>
            <div><h4>23</h4><span>Total Causes</span></div>
            <div><h4>₹ 2052400.00</h4><span>Donation Raised</span></div>
          </div>
          <Link to="/cause" className="btn">Support a Cause</Link>
        </div>
        <div><h4>About Us</h4><ul>{about.map(([l, t]) => <li key={l}><Link to={t}>{l}</Link></li>)}</ul></div>
        <div><h4>Our Projects</h4><ul>{projects.map(([l, t]) => <li key={l}><Link to={t}>{l}</Link></li>)}</ul></div>
        <div><h4>Get Involved</h4><ul>{involve.map(([l, t]) => <li key={l}><Link to={t}>{l}</Link></li>)}</ul></div>
        <div><h4>News & Events</h4><ul>{events.map((e) => <li key={e.slug}><Link to={`/events/${e.slug}`}>{e.title.slice(0, 50)}...</Link></li>)}</ul></div>
        <div><h4>Resource Center</h4><ul>{resources.map(([l, t]) => <li key={l}><Link to={t}>{l}</Link></li>)}</ul></div>
      </div>
      <div className="container ft-tags">
        <div><h5>Festive Ocassion</h5><p>Donate joy on the days that matter most.</p><div className="chips">{fest.map((f) => <Link key={f.slug} to={`/${f.slug}`}>{f.name}</Link>)}</div></div>
        <div><h5>Special Occasion</h5><p>Mark milestones with a meaningful gift.</p><div className="chips">{occasions.map((o) => <Link key={o.slug} to={`/${o.slug}`}>{o.name}</Link>)}</div></div>
      </div>
      <div className="container ft-mid">
        <div>
          <h4>Connect with us</h4>
          <p>Donations to Suma Blessings Foundation are tax exempted under section 80G.</p>
          <ul><li><a href="tel:+919971759656">{PHONE}</a></li><li><a href={`mailto:${EMAIL}`}>{EMAIL}</a></li></ul>
          <h4 className="gap">Follow us on Social Media</h4>
          <p>Stories, updates, and impact straight from our community.</p>
          <div className="soc">{socials.map(([n, u]) => <a key={n} href={u} target="_blank" rel="noreferrer" aria-label={n}>{letters[n]}</a>)}</div>
        </div>
        <div>
          <h4>Subscribe to our newsletter</h4>
          <p>Subscribe here and don't miss any update</p>
          {done ? <div className="thanks">Thank you for subscribing!</div> : (
            <form className="sub-form" onSubmit={(e) => { e.preventDefault(); setDone(true); setEmail(''); }}>
              <input type="email" required placeholder="Email Address" value={email} onChange={(e) => setEmail(e.target.value)} />
              <button className="btn">Subscribe</button>
            </form>
          )}
        </div>
      </div>
      <div className="container ft-disc"><b>Disclaimer</b><p>The use of children’s information, including images, videos, testimonials, etc., in the Campaign is essential for raising awareness about the charitable cause, with the aim of attracting support and donations that can be utilized for charitable activities. This information is used and processed with valid consent. This statement is issued in compliance with the Consumer Protection Act, 2019, as amended from time to time.</p></div>
      <div className="ft-bottom"><div className="container">
        <span>Copyright © 2026 | All Rights Reserved to Suma Blessings Foundation. Website Developed by eformax</span>
        <ul><li><Link to="/privacy-policy">Privacy & Policy</Link></li><li><Link to="/terms-and-condition">Terms & Condition</Link></li><li><Link to="/refund-policy">Refund Policy</Link></li></ul>
      </div></div>
    </footer>
  );
}
