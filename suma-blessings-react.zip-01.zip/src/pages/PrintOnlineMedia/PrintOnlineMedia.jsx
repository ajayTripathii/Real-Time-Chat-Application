import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './PrintOnlineMedia.css';

export default function PrintOnlineMedia() {
  return (
    <>
      <PageBanner title="Print / Online Media" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Suma Blessings in the news</h2>
            <p>Read how newspapers, magazines and online platforms have covered our work.</p>
            <p>Add media coverage links and clippings here.</p>
            <ul className="ip-list">
              <li>Newspaper features</li>
              <li>Magazine mentions</li>
              <li>Online articles</li>
              <li>Press releases</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
