import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './MissionVision.css';

export default function MissionVision() {
  return (
    <>
      <PageBanner title="Mission & Vision" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Our purpose and the future we are building</h2>
            <p>Our mission is to protect the rights of every child, woman and senior citizen by providing access to education, healthcare, nutrition and livelihood.</p>
            <p>Our vision is a society where every individual lives with dignity, equal opportunity and hope.</p>
            <ul className="ip-list">
              <li>Dignity for every individual</li>
              <li>Equal access to opportunity</li>
              <li>Community-led change</li>
              <li>Accountability in every rupee</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
