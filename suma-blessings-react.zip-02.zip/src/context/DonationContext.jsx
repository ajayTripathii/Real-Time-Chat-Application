import { createContext, useContext, useState } from 'react';

const Ctx = createContext(null);
export const useDonation = () => useContext(Ctx);

export function DonationProvider({ children }) {
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);
  const add = (item) => {
    setItems((p) => [...p.filter((i) => i.id !== item.id), item]);
    setOpen(true);
  };
  const remove = (id) => setItems((p) => p.filter((i) => i.id !== id));
  const clear = () => setItems([]);
  const total = items.reduce((s, i) => s + Number(i.amount || 0), 0);
  return <Ctx.Provider value={{ items, add, remove, clear, total, open, setOpen }}>{children}</Ctx.Provider>;
}
