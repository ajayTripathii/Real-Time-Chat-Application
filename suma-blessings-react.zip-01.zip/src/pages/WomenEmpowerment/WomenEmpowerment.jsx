import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './WomenEmpowerment.css';

export default function WomenEmpowerment() {
  return (
    <>
      <PageBanner title="Women Empowerment" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>Supporting women in realizing their dreams</h2>
            <p>Silai Se Samriddhi trains women in tailoring and builds self-help groups so they can earn with dignity.</p>
            <p>200+ women have enrolled, with 10+ self-help groups formed and 30+ women trained per batch.</p>
            <ul className="ip-list">
              <li>Tailoring and vocational training</li>
              <li>Self-help groups</li>
              <li>Financial literacy</li>
              <li>Health and hygiene support</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
