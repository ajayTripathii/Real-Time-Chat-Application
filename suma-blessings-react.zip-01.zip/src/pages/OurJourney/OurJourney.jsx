import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './OurJourney.css';

export default function OurJourney() {
  return (
    <>
      <PageBanner title="Our Journey" />
      <section className="section">
        <div className="container ip-grid">
          <div className="ip-main">
            <h2>From a small initiative in 2021 to a growing movement</h2>
            <p>Suma Blessings Foundation began in 2021 with a simple idea: help one child, then one community, then many.</p>
            <p>Today we run 15+ education centers and schools, have served 1 million+ meals and support 5000+ students.</p>
            <ul className="ip-list">
              <li>2021 – Foundation established</li>
              <li>Suma Vidyalaya starts for children in need</li>
              <li>Healthcare and nutrition programmes expand</li>
              <li>Skill development and women empowerment initiatives launch</li>
            </ul>
          </div>
          <aside className="ip-side">
            <h3>Be part of the change</h3>
            <p>Your support is eligible for 80G tax benefit.</p>
            <Link to="/donate-now" className="btn">Donate Now</Link>
          </aside>
        </div>
      </section>
    </>
  );
}
