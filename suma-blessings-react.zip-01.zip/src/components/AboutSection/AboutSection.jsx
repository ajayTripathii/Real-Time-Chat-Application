import { Link } from 'react-router-dom';
import { aboutStats } from '../../data/siteData';
import './AboutSection.css';

export default function AboutSection() {
  return (
    <section className="section alt ab">
      <div className="container">
        <div className="ab-grid">
          <div className="ab-img">
            <img src="https://www.sumablessings.org/assets/images/frontend/about/63abd8f9c91331672206585.jpg" alt="About Suma Blessings Foundation" loading="lazy" />
            <div className="ab-badge"><b>1M+</b><span>People benefited through our programmes</span></div>
          </div>
          <div>
            <span className="eyebrow">About us</span>
            <h2>About Suma Blessings Foundation</h2>
            <p className="ab-p">Suma Blessings Foundation, established in 2021, is a not for profit organization committed to the holistic development of marginalized communities.</p>
            <ul className="ab-tags"><li>Education</li><li>Healthcare</li><li>Community</li></ul>
            <Link to="/about" className="btn">Learn more</Link>
          </div>
        </div>
        <ul className="ab-stats">
          {aboutStats.map(([n, l]) => (<li key={l}><b>{n}</b><span>{l}</span></li>))}
        </ul>
      </div>
    </section>
  );
}
