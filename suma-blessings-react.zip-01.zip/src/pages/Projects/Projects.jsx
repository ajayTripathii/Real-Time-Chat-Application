import PageBanner from '../../components/PageBanner/PageBanner';
import ProjectsSection from '../../components/ProjectsSection/ProjectsSection';
import './Projects.css';

export default function Projects() {
  return (<><PageBanner title="Our Projects" /><div className="projects-page"><ProjectsSection /></div></>);
}
