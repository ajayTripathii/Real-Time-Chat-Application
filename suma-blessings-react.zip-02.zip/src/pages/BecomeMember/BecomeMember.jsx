import { useState } from 'react';
import PageBanner from '../../components/PageBanner/PageBanner';
import { useToast } from '../../context/ToastContext';
import './BecomeMember.css';

const fields = [["Full name", "text"], ["Email", "email"], ["Mobile", "tel"], ["City", "text"], ["Monthly contribution (\u20b9)", "number"]];

export default function BecomeMember() {
  const [sent, setSent] = useState(false);
  const toast = useToast();
  return (
    <>
      <PageBanner title="Membership" />
      <section className="section alt">
        <div className="container fm-wrap">
          <div className="fm-intro">
            <h2>Membership</h2>
            <p>Membership is open to everyone who may not have the time or ability to work online or offline. Contribute a monthly donation and become a member.</p>
          </div>
          <form className="card fm-card" onSubmit={(e) => { e.preventDefault(); setSent(true); toast('Submitted successfully. We will contact you soon.'); }}>
            {sent ? <div className="thanks">Thank you! We have received your details and will contact you soon.</div> : (
              <div className="form-grid">
                {fields.map(([label, type]) => (
                  <div className="field" key={label}><label>{label}</label><input type={type} required /></div>
                ))}
                <div className="field full"><label>Message (optional)</label><textarea rows="4" /></div>
                <div className="full"><button className="btn">Apply now</button></div>
              </div>
            )}
          </form>
        </div>
      </section>
    </>
  );
}
