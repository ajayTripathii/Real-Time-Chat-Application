import { Link } from 'react-router-dom';
import PageBanner from '../../components/PageBanner/PageBanner';
import './Login.css';

export default function Login() {
  return (
    <>
      <PageBanner title="Login" />
      <section className="section alt">
        <div className="container">
          <form className="card au-card" onSubmit={(e) => e.preventDefault()}>
            <h2>Welcome back</h2>
            <div className="field"><label>Username or Email</label><input required /></div>
            <div className="field"><label>Password</label><input type="password" required /></div>
            <button className="btn">Login</button>
            <p>New here? <Link to="/register">Create an account</Link></p>
          </form>
        </div>
      </section>
    </>
  );
}
