import { useState } from 'react';
import { whatsappTeam, WHATSAPP, FAVICON } from '../../data/siteData';
import './WhatsAppChat.css';

export default function WhatsAppChat() {
  const [open, setOpen] = useState(false);
  return (
    <div className="wa">
      {open && (
        <div className="wa-box">
          <div className="wa-head">
            <b>Start a Conversation</b>
            <p>Hi! Click a team member below to chat on <b>WhatsApp</b></p>
            <small>The team typically replies in a few minutes.</small>
          </div>
          <ul>
            {whatsappTeam.map(([n, r]) => (
              <li key={n}><a href={WHATSAPP} target="_blank" rel="noreferrer"><img src={FAVICON} alt="" /><span><b>{n}</b><em>{r}</em></span></a></li>
            ))}
          </ul>
          <p className="wa-foot">Suma Blessings Foundation — here to help with donations & enquiries</p>
        </div>
      )}
      <button className="wa-btn" onClick={() => setOpen(!open)} aria-label="Chat on WhatsApp">{open ? '✕' : '💬'}</button>
    </div>
  );
}
