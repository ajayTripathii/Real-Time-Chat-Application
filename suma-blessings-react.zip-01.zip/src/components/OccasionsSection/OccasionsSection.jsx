import { Link } from 'react-router-dom';
import { occasions } from '../../data/siteData';
import './OccasionsSection.css';

export default function OccasionsSection() {
  return (
    <section className="section">
      <div className="container">
        <div className="sec-head">
          <span className="eyebrow">Mark a milestone</span>
          <h2>Special Occasion Donation</h2>
          <p>Whether it's a birthday, anniversary, or graduation, make a donation in honor of your loved ones with us.</p>
        </div>
        <div className="oc-grid">
          {occasions.map((o) => (
            <Link key={o.slug} to={`/${o.slug}`} className="oc-card">
              <img src={o.img} alt={o.name} loading="lazy" />
              <h3>{o.name}</h3>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
